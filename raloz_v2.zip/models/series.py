# coding: utf-8
import sqlite3
from datetime import datetime

def obtener_siguiente_numero(db_path, tipo):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("SELECT prefijo, siguiente_numero FROM series WHERE tipo=?", (tipo,))
    row = cur.fetchone()
    if row:
        prefijo, num = row
        nuevo_num = num + 1
        cur.execute("UPDATE series SET siguiente_numero=? WHERE tipo=?", (nuevo_num, tipo))
        conn.commit()
        numero = f"{prefijo}{num:06d}"
    else:
        numero = f"{tipo[:2]}{datetime.now().strftime('%Y%m%d%H%M%S')}"
    conn.close()
    return numero
