# 👔 RALOZ COL SAS - Sistema de Facturación v2.0

Sistema de facturación profesional para empresa de uniformes escolares.

## 🚀 Características

- ✅ **Dashboard** con KPIs y gráficas en tiempo real
- ✅ **Punto de Venta (POS)** con escáner de código de barras
- ✅ **Catálogo Visual** de productos con fotos
- ✅ **Gestión de Inventario** por tallas con alertas de stock
- ✅ **Facturación** completa con impresión térmica
- ✅ **Clientes** con historial de compras
- ✅ **Caja y Arqueo** diario
- ✅ **Reportes** con gráficas y exportación
- ✅ **Multi-usuario** con roles (admin/vendedor)
- ✅ **Tema Corporativo** (Amarillo, Azul, Rojo)

## 📋 Requisitos

- Python 3.8 o superior
- Windows 10/11, Linux o macOS

## 🔧 Instalación

1. **Instalar dependencias:**
```bash
pip install -r requirements.txt
```

2. **Ejecutar el sistema:**
```bash
python main.py
```

3. **Credenciales por defecto:**
   - Usuario: `admin`
   - Contraseña: `1234`

## 📁 Estructura del Proyecto

```
raloz_v2/
├── main.py              # Punto de entrada
├── setup.py             # Inicialización de BD
├── requirements.txt     # Dependencias
├── data/                # Base de datos SQLite
├── modules/             # Módulos del sistema
│   ├── login.py
│   ├── dashboard.py
│   ├── pos_module.py
│   ├── catalogo_module.py
│   ├── facturacion_module.py
│   ├── clientes_module.py
│   ├── inventario_module.py
│   ├── caja_module.py
│   ├── reportes_module.py
│   └── config_module.py
├── utils/               # Utilidades
│   ├── tema_corporativo.py
│   ├── money_parser.py
│   └── impresora.py
├── models/              # Modelos de datos
│   └── series.py
└── assets/              # Recursos (imágenes)
```

## 🖨️ Impresora Térmica

Compatible con impresoras ESC/POS (Epson, Bixolon, etc.)

Para activar:
1. Conectar impresora USB
2. Ir a Configuración > Impresora
3. Activar y configurar

## 📊 Módulos

| Módulo | Descripción |
|--------|-------------|
| 📊 Dashboard | Resumen de ventas, KPIs, gráficas |
| 🛒 POS | Punto de venta rápido con escáner |
| 📦 Catálogo | Gestión visual de productos |
| 🧾 Facturación | Lista de facturas, impresión |
| 👥 Clientes | Base de clientes con historial |
| 📋 Inventario | Stock por talla, alertas |
| 🏦 Caja | Apertura, cierre, arqueo |
| 📈 Reportes | Análisis con gráficas |
| ⚙️ Config | Empresa, usuarios, categorías |

## 🎨 Colores Corporativos

- **Amarillo:** #FFC107
- **Azul:** #1976D2
- **Rojo:** #D32F2F

## 📝 Licencia

Desarrollado para RALOZ COL SAS

---
Versión 2.0 | 2026
