# coding: utf-8
"""
RALOZ COL SAS - Sistema de Facturación v2.0
Empresa de Uniformes Escolares
"""
import tkinter as tk
from tkinter import messagebox
import sys
import os

# Agregar path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from setup import inicializar_db
from utils.tema_corporativo import aplicar_tema, COLORES
from modules.login import LoginWindow
from modules.dashboard import DashboardModule

# Configuración
DB_PATH = "data/raloz.db"


class AplicacionRALOZ:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("RALOZ COL SAS - Sistema de Facturación")
        self.root.geometry("1400x800")
        self.root.minsize(1200, 700)
        self.root.configure(bg=COLORES['fondo_principal'])
        
        # Centrar ventana
        self._centrar_ventana()
        
        # Inicializar BD
        inicializar_db(DB_PATH)
        
        # Aplicar tema
        aplicar_tema(self.root)
        
        # Usuario actual
        self.usuario = None
        
        # Mostrar login
        self._mostrar_login()
        
        # Iniciar loop
        self.root.mainloop()
    
    def _centrar_ventana(self):
        self.root.update_idletasks()
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        x = (sw - 1400) // 2
        y = (sh - 800) // 2
        self.root.geometry(f"1400x800+{x}+{y}")
    
    def _mostrar_login(self):
        for w in self.root.winfo_children():
            w.destroy()
        LoginWindow(self.root, DB_PATH, self._on_login_success)
    
    def _on_login_success(self, usuario):
        self.usuario = usuario
        self._mostrar_dashboard()
    
    def _mostrar_dashboard(self):
        for w in self.root.winfo_children():
            w.destroy()
        DashboardModule(self.root, self.usuario, DB_PATH, self._cambiar_modulo)
    
    def _cambiar_modulo(self, modulo):
        """Cambia el módulo activo"""
        # Limpiar área de contenido
        for w in self.root.winfo_children():
            w.destroy()
        
        # Recrear dashboard con el módulo seleccionado
        from modules.dashboard import DashboardModule
        dashboard = DashboardModule(self.root, self.usuario, DB_PATH, self._cambiar_modulo)
        
        # Cargar módulo específico
        if modulo == 'pos':
            self._cargar_modulo_en_dashboard('pos')
        elif modulo == 'catalogo':
            self._cargar_modulo_en_dashboard('catalogo')
        elif modulo == 'facturas':
            self._cargar_modulo_en_dashboard('facturas')
        elif modulo == 'clientes':
            self._cargar_modulo_en_dashboard('clientes')
        elif modulo == 'inventario':
            self._cargar_modulo_en_dashboard('inventario')
        elif modulo == 'caja':
            self._cargar_modulo_en_dashboard('caja')
        elif modulo == 'reportes':
            self._cargar_modulo_en_dashboard('reportes')
        elif modulo == 'config':
            self._cargar_modulo_en_dashboard('config')
    
    def _cargar_modulo_en_dashboard(self, modulo):
        """Carga un módulo dentro del área de contenido del dashboard"""
        # Buscar el content_area del dashboard
        for w in self.root.winfo_children():
            if hasattr(w, 'winfo_children'):
                for child in w.winfo_children():
                    # El content_area es el frame principal después del sidebar
                    if isinstance(child, tk.Frame) and child.cget('bg') == COLORES['fondo_principal']:
                        # Encontramos el content_area, ahora buscamos en sus hijos
                        pass
        
        # Reconstruir dashboard con módulo específico
        for w in self.root.winfo_children():
            w.destroy()
        
        self._crear_layout_con_modulo(modulo)
    
    def _crear_layout_con_modulo(self, modulo_activo):
        """Crea el layout principal con sidebar y módulo específico"""
        from utils.tema_corporativo import PanelLateral, COLORES
        
        main_container = tk.Frame(self.root, bg=COLORES['fondo_principal'])
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Sidebar
        sidebar = PanelLateral(main_container)
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.agregar_header("RALOZ", f"v2.0 | {self.usuario['rol'].upper()}")
        sidebar.agregar_separador()
        
        menus = [
            ('dashboard', 'Dashboard', '📊', lambda: self._mostrar_dashboard()),
            ('pos', 'Punto de Venta', '🛒', lambda: self._cambiar_modulo('pos')),
            ('catalogo', 'Catálogo', '📦', lambda: self._cambiar_modulo('catalogo')),
            ('facturas', 'Facturación', '🧾', lambda: self._cambiar_modulo('facturas')),
            ('clientes', 'Clientes', '👥', lambda: self._cambiar_modulo('clientes')),
            ('inventario', 'Inventario', '📋', lambda: self._cambiar_modulo('inventario')),
            ('caja', 'Caja', '🏦', lambda: self._cambiar_modulo('caja')),
            ('reportes', 'Reportes', '📈', lambda: self._cambiar_modulo('reportes')),
        ]
        
        for key, texto, icono, cmd in menus:
            sidebar.agregar_boton(key, texto, icono, cmd)
        
        sidebar.agregar_separador()
        
        if self.usuario['rol'] == 'admin':
            sidebar.agregar_boton('config', 'Configuración', '⚙️', lambda: self._cambiar_modulo('config'))
        
        sidebar.agregar_boton('salir', 'Cerrar Sesión', '🚪', self._cerrar_sesion)
        sidebar.activar_boton(modulo_activo)
        
        # Área de contenido
        content_area = tk.Frame(main_container, bg=COLORES['fondo_principal'])
        content_area.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Cargar módulo
        if modulo_activo == 'pos':
            from modules.pos_module import POSModule
            POSModule(content_area, self.usuario, DB_PATH)
        elif modulo_activo == 'catalogo':
            from modules.catalogo_module import CatalogoModule
            CatalogoModule(content_area, self.usuario, DB_PATH)
        elif modulo_activo == 'facturas':
            from modules.facturacion_module import FacturacionModule
            FacturacionModule(content_area, self.usuario, DB_PATH)
        elif modulo_activo == 'clientes':
            from modules.clientes_module import ClientesModule
            ClientesModule(content_area, self.usuario, DB_PATH)
        elif modulo_activo == 'inventario':
            from modules.inventario_module import InventarioModule
            InventarioModule(content_area, self.usuario, DB_PATH)
        elif modulo_activo == 'caja':
            from modules.caja_module import CajaModule
            CajaModule(content_area, self.usuario, DB_PATH)
        elif modulo_activo == 'reportes':
            from modules.reportes_module import ReportesModule
            ReportesModule(content_area, self.usuario, DB_PATH)
        elif modulo_activo == 'config':
            from modules.config_module import ConfigModule
            ConfigModule(content_area, self.usuario, DB_PATH)
    
    def _cerrar_sesion(self):
        if messagebox.askyesno("Cerrar Sesión", "¿Desea cerrar sesión?"):
            self._mostrar_login()


def iniciar_app():
    AplicacionRALOZ()


if __name__ == "__main__":
    iniciar_app()
