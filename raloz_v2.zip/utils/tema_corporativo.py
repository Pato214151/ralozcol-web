# coding: utf-8
"""
RALOZ COL SAS - Tema Corporativo Moderno
Colores: Amarillo, Azul, Rojo
"""
import tkinter as tk
from tkinter import ttk

# Colores Corporativos RALOZ
COLORES = {
    # Primarios
    'amarillo': '#FFC107',
    'amarillo_hover': '#FFB300',
    'amarillo_claro': '#FFF8E1',
    'azul': '#1976D2',
    'azul_hover': '#1565C0',
    'azul_claro': '#E3F2FD',
    'azul_oscuro': '#0D47A1',
    'rojo': '#D32F2F',
    'rojo_hover': '#C62828',
    'rojo_claro': '#FFEBEE',
    
    # Neutros
    'blanco': '#FFFFFF',
    'gris_claro': '#F5F5F5',
    'gris': '#E0E0E0',
    'gris_medio': '#9E9E9E',
    'gris_oscuro': '#616161',
    'negro': '#212121',
    'negro_suave': '#424242',
    
    # Estados
    'exito': '#4CAF50',
    'exito_hover': '#388E3C',
    'advertencia': '#FF9800',
    'error': '#F44336',
    'info': '#2196F3',
    
    # Dashboard
    'fondo_principal': '#FAFAFA',
    'sidebar': '#1A237E',
    'sidebar_hover': '#283593',
    'sidebar_activo': '#3949AB',
}

FUENTES = {
    'titulo': ('Segoe UI', 28, 'bold'),
    'subtitulo': ('Segoe UI', 20, 'bold'),
    'header': ('Segoe UI', 16, 'bold'),
    'grande': ('Segoe UI', 14, 'bold'),
    'normal': ('Segoe UI', 11),
    'normal_bold': ('Segoe UI', 11, 'bold'),
    'pequeña': ('Segoe UI', 9),
    'precio': ('Segoe UI', 24, 'bold'),
    'kpi': ('Segoe UI', 36, 'bold'),
    'mono': ('Consolas', 10),
}


def aplicar_tema(root):
    style = ttk.Style()
    style.theme_use('clam')
    
    style.configure('Treeview',
        background=COLORES['blanco'],
        foreground=COLORES['negro'],
        rowheight=40,
        fieldbackground=COLORES['blanco'],
        font=FUENTES['normal']
    )
    style.configure('Treeview.Heading',
        background=COLORES['azul'],
        foreground=COLORES['blanco'],
        font=FUENTES['normal_bold'],
        padding=(10, 10)
    )
    style.map('Treeview',
        background=[('selected', COLORES['amarillo'])],
        foreground=[('selected', COLORES['negro'])]
    )
    
    style.configure('TEntry', padding=10, font=FUENTES['normal'])
    style.configure('TCombobox', padding=8, font=FUENTES['normal'])
    style.configure('TNotebook', background=COLORES['gris_claro'])
    style.configure('TNotebook.Tab', font=FUENTES['normal'], padding=[20, 10])
    
    return style


class BotonModerno(tk.Canvas):
    def __init__(self, parent, texto="", icono="", comando=None, 
                 ancho=150, alto=45, estilo="primario", **kwargs):
        super().__init__(parent, width=ancho, height=alto, 
                        highlightthickness=0, bg=parent.cget('bg'), **kwargs)
        
        self.texto = texto
        self.icono = icono
        self.comando = comando
        self.ancho = ancho
        self.alto = alto
        
        estilos = {
            'primario': (COLORES['azul'], COLORES['azul_hover'], COLORES['blanco']),
            'secundario': (COLORES['amarillo'], COLORES['amarillo_hover'], COLORES['negro']),
            'peligro': (COLORES['rojo'], COLORES['rojo_hover'], COLORES['blanco']),
            'exito': (COLORES['exito'], COLORES['exito_hover'], COLORES['blanco']),
            'oscuro': (COLORES['negro'], COLORES['negro_suave'], COLORES['blanco']),
            'claro': (COLORES['gris'], COLORES['gris_claro'], COLORES['negro']),
            'outline': (COLORES['blanco'], COLORES['azul_claro'], COLORES['azul']),
        }
        
        self.color_normal, self.color_hover, self.color_texto = estilos.get(estilo, estilos['primario'])
        self.color_actual = self.color_normal
        self._dibujar()
        
        self.bind('<Enter>', self._on_enter)
        self.bind('<Leave>', self._on_leave)
        self.bind('<Button-1>', self._on_click)
        self.bind('<ButtonRelease-1>', self._on_release)
    
    def _dibujar(self):
        self.delete('all')
        radio = 8
        x1, y1, x2, y2 = 2, 2, self.ancho-2, self.alto-2
        puntos = [x1+radio, y1, x2-radio, y1, x2, y1, x2, y1+radio,
                  x2, y2-radio, x2, y2, x2-radio, y2, x1+radio, y2,
                  x1, y2, x1, y2-radio, x1, y1+radio, x1, y1]
        self.create_polygon(puntos, fill=self.color_actual, outline='', smooth=True)
        texto_mostrar = f"{self.icono} {self.texto}" if self.icono else self.texto
        self.create_text(self.ancho/2, self.alto/2, text=texto_mostrar,
                        fill=self.color_texto, font=FUENTES['normal_bold'])
    
    def _on_enter(self, event):
        self.color_actual = self.color_hover
        self._dibujar()
        self.config(cursor='hand2')
    
    def _on_leave(self, event):
        self.color_actual = self.color_normal
        self._dibujar()
    
    def _on_click(self, event):
        self.move('all', 1, 1)
    
    def _on_release(self, event):
        self.move('all', -1, -1)
        if self.comando:
            self.comando()


class TarjetaKPI(tk.Frame):
    def __init__(self, parent, titulo="", valor="0", icono="📊", 
                 color=None, tendencia=None, **kwargs):
        super().__init__(parent, **kwargs)
        
        self.color = color or COLORES['azul']
        self.configure(bg=COLORES['blanco'], highlightthickness=0)
        
        barra = tk.Frame(self, bg=self.color, height=5)
        barra.pack(fill=tk.X)
        
        contenido = tk.Frame(self, bg=COLORES['blanco'])
        contenido.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)
        
        header = tk.Frame(contenido, bg=COLORES['blanco'])
        header.pack(fill=tk.X)
        tk.Label(header, text=icono, font=('Segoe UI', 28), 
                bg=COLORES['blanco'], fg=self.color).pack(side=tk.LEFT)
        tk.Label(header, text=titulo, font=FUENTES['normal'],
                bg=COLORES['blanco'], fg=COLORES['gris_oscuro']).pack(side=tk.LEFT, padx=10)
        
        self.lbl_valor = tk.Label(contenido, text=str(valor), font=FUENTES['kpi'],
                bg=COLORES['blanco'], fg=COLORES['negro'])
        self.lbl_valor.pack(anchor='w')
        
        if tendencia:
            color_tend = COLORES['exito'] if tendencia > 0 else COLORES['rojo']
            signo = "▲" if tendencia > 0 else "▼"
            tk.Label(contenido, text=f"{signo} {abs(tendencia)}%", 
                    font=FUENTES['pequeña'], bg=COLORES['blanco'], fg=color_tend).pack(anchor='w')
    
    def actualizar_valor(self, valor):
        self.lbl_valor.config(text=str(valor))


class TarjetaProducto(tk.Frame):
    def __init__(self, parent, producto, comando_click=None, **kwargs):
        super().__init__(parent, **kwargs)
        
        self.producto = producto
        self.comando = comando_click
        self.configure(bg=COLORES['blanco'], cursor='hand2',
                      highlightthickness=1, highlightbackground=COLORES['gris'])
        
        frame_img = tk.Frame(self, bg=COLORES['gris_claro'], width=120, height=120)
        frame_img.pack(padx=10, pady=10)
        frame_img.pack_propagate(False)
        
        tk.Label(frame_img, text="👔", font=('Segoe UI', 48), 
                bg=COLORES['gris_claro']).pack(expand=True)
        
        tk.Label(self, text=producto.get('nombre', '')[:20], 
                font=FUENTES['normal_bold'], bg=COLORES['blanco']).pack()
        
        precio = producto.get('precio_venta', 0)
        tk.Label(self, text=f"${precio:,.0f}".replace(',', '.'), 
                font=FUENTES['grande'], bg=COLORES['blanco'], 
                fg=COLORES['azul']).pack()
        
        stock = producto.get('stock', 0)
        color_stock = COLORES['exito'] if stock > 5 else COLORES['rojo'] if stock > 0 else COLORES['gris_oscuro']
        tk.Label(self, text=f"Stock: {stock}", font=FUENTES['pequeña'],
                bg=COLORES['blanco'], fg=color_stock).pack(pady=(0,10))
        
        self.bind('<Enter>', self._on_enter)
        self.bind('<Leave>', self._on_leave)
        self.bind('<Button-1>', self._on_click)
        for child in self.winfo_children():
            child.bind('<Button-1>', self._on_click)
    
    def _on_enter(self, e):
        self.configure(highlightbackground=COLORES['azul'], highlightthickness=2)
    
    def _on_leave(self, e):
        self.configure(highlightbackground=COLORES['gris'], highlightthickness=1)
    
    def _on_click(self, e):
        if self.comando:
            self.comando(self.producto)


class PanelLateral(tk.Frame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg=COLORES['sidebar'], width=240, **kwargs)
        self.pack_propagate(False)
        self.botones = {}
        self.boton_activo = None
    
    def agregar_header(self, texto, subtexto=""):
        frame = tk.Frame(self, bg=COLORES['sidebar'])
        frame.pack(fill=tk.X, pady=25)
        tk.Label(frame, text=texto, font=FUENTES['subtitulo'],
                bg=COLORES['sidebar'], fg=COLORES['amarillo']).pack()
        if subtexto:
            tk.Label(frame, text=subtexto, font=FUENTES['pequeña'],
                    bg=COLORES['sidebar'], fg=COLORES['gris']).pack()
    
    def agregar_separador(self):
        tk.Frame(self, bg=COLORES['sidebar_hover'], height=1).pack(fill=tk.X, padx=20, pady=10)
    
    def agregar_boton(self, key, texto, icono="", comando=None):
        btn = tk.Frame(self, bg=COLORES['sidebar'], cursor='hand2')
        btn.pack(fill=tk.X, padx=10, pady=2)
        
        contenido = tk.Frame(btn, bg=COLORES['sidebar'])
        contenido.pack(fill=tk.X, padx=15, pady=12)
        
        texto_completo = f"{icono}  {texto}" if icono else texto
        lbl = tk.Label(contenido, text=texto_completo, font=FUENTES['normal'],
                      bg=COLORES['sidebar'], fg=COLORES['blanco'], anchor='w')
        lbl.pack(side=tk.LEFT)
        
        def on_enter(e):
            if self.boton_activo != key:
                btn.configure(bg=COLORES['sidebar_hover'])
                contenido.configure(bg=COLORES['sidebar_hover'])
                lbl.configure(bg=COLORES['sidebar_hover'])
        
        def on_leave(e):
            if self.boton_activo != key:
                btn.configure(bg=COLORES['sidebar'])
                contenido.configure(bg=COLORES['sidebar'])
                lbl.configure(bg=COLORES['sidebar'])
        
        def on_click(e):
            if comando:
                comando()
        
        for widget in [btn, contenido, lbl]:
            widget.bind('<Enter>', on_enter)
            widget.bind('<Leave>', on_leave)
            widget.bind('<Button-1>', on_click)
        
        self.botones[key] = {'frame': btn, 'contenido': contenido, 'label': lbl}
    
    def activar_boton(self, key):
        if self.boton_activo and self.boton_activo in self.botones:
            b = self.botones[self.boton_activo]
            b['frame'].configure(bg=COLORES['sidebar'])
            b['contenido'].configure(bg=COLORES['sidebar'])
            b['label'].configure(bg=COLORES['sidebar'], fg=COLORES['blanco'])
        
        if key in self.botones:
            b = self.botones[key]
            b['frame'].configure(bg=COLORES['sidebar_activo'])
            b['contenido'].configure(bg=COLORES['sidebar_activo'])
            b['label'].configure(bg=COLORES['sidebar_activo'], fg=COLORES['amarillo'])
            self.boton_activo = key


class HeaderModerno(tk.Frame):
    def __init__(self, parent, titulo="", icono="", color=None, **kwargs):
        color = color or COLORES['azul']
        super().__init__(parent, bg=color, height=70, **kwargs)
        self.pack_propagate(False)
        
        contenido = tk.Frame(self, bg=color)
        contenido.pack(fill=tk.BOTH, expand=True, padx=30)
        
        texto = f"{icono}  {titulo}" if icono else titulo
        tk.Label(contenido, text=texto, font=FUENTES['titulo'],
                bg=color, fg=COLORES['blanco']).pack(side=tk.LEFT, pady=15)
        
        tk.Frame(self, bg=COLORES['amarillo'], height=4).pack(side=tk.BOTTOM, fill=tk.X)
