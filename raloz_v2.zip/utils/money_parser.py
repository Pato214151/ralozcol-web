# coding: utf-8
"""Formateo de dinero colombiano"""

def format_money(valor):
    """Formatea número a pesos colombianos"""
    try:
        return f"${valor:,.0f}".replace(',', '.')
    except:
        return "$0"

def parse_money(texto):
    """Convierte texto a número"""
    try:
        limpio = texto.replace('$', '').replace('.', '').replace(',', '.').strip()
        return float(limpio)
    except:
        return 0.0
