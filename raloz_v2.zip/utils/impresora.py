# coding: utf-8
"""
Módulo de impresión térmica POS
Compatible con impresoras ESC/POS
"""
from datetime import datetime

try:
    from escpos.printer import Usb, Network
    ESCPOS_DISPONIBLE = True
except ImportError:
    ESCPOS_DISPONIBLE = False

class ImpresoraPOS:
    def __init__(self, tipo='usb', **kwargs):
        self.tipo = tipo
        self.printer = None
        self.config = kwargs
        
    def conectar(self):
        """Intenta conectar con la impresora"""
        if not ESCPOS_DISPONIBLE:
            return False, "python-escpos no instalado"
        
        try:
            if self.tipo == 'usb':
                self.printer = Usb(
                    self.config.get('vendor_id', 0x04b8),
                    self.config.get('product_id', 0x0e15)
                )
            elif self.tipo == 'red':
                self.printer = Network(
                    self.config.get('ip', '192.168.1.100'),
                    self.config.get('port', 9100)
                )
            return True, "Conectado"
        except Exception as e:
            return False, str(e)
    
    def imprimir_factura(self, factura, empresa, items):
        """Imprime factura POS"""
        if not self.printer:
            return False, "Impresora no conectada"
        
        try:
            p = self.printer
            
            # Encabezado
            p.set(align='center', bold=True, double_height=True, double_width=True)
            p.text(f"{empresa['nombre']}\n")
            p.set(align='center', bold=False, double_height=False, double_width=False)
            p.text(f"NIT: {empresa['nit']}\n")
            p.text(f"{empresa['direccion']}\n")
            p.text(f"Tel: {empresa['telefono']}\n")
            p.text("-" * 32 + "\n")
            
            # Info factura
            p.set(align='left')
            p.text(f"Factura: {factura['numero']}\n")
            p.text(f"Fecha: {factura['fecha']} {factura['hora']}\n")
            p.text(f"Cliente: {factura['cliente']}\n")
            p.text("=" * 32 + "\n")
            
            # Items
            for item in items:
                nombre = item['nombre'][:18]
                cant = item['cantidad']
                total = item['total']
                p.text(f"{cant:2d} {nombre:<18} ${total:>8,.0f}\n".replace(',', '.'))
            
            # Totales
            p.text("-" * 32 + "\n")
            p.text(f"{'Subtotal:':<20} ${factura['subtotal']:>10,.0f}\n".replace(',', '.'))
            if factura.get('descuento', 0) > 0:
                p.text(f"{'Descuento:':<20} ${factura['descuento']:>10,.0f}\n".replace(',', '.'))
            p.text(f"{'IVA:':<20} ${factura['iva']:>10,.0f}\n".replace(',', '.'))
            p.set(bold=True, double_height=True)
            p.text(f"{'TOTAL:':<20} ${factura['total']:>10,.0f}\n".replace(',', '.'))
            p.set(bold=False, double_height=False)
            
            # Método de pago
            p.text(f"\nPago: {factura['metodo_pago']}\n")
            
            # QR DIAN (si tiene)
            if factura.get('cufe'):
                p.text("\n")
                p.qr(f"https://catalogo-vpfe.dian.gov.co/document/searchqr?documentkey={factura['cufe']}", size=6)
            
            # Pie
            p.set(align='center')
            p.text("\n¡Gracias por su compra!\n")
            p.text("www.raloz.com\n")
            p.text("\n\n\n")
            p.cut()
            
            return True, "Impreso correctamente"
        except Exception as e:
            return False, str(e)
    
    def imprimir_texto(self, texto):
        """Imprime texto simple"""
        if not self.printer:
            return False, "Impresora no conectada"
        try:
            self.printer.text(texto)
            self.printer.cut()
            return True, "OK"
        except Exception as e:
            return False, str(e)


def generar_ticket_texto(factura, empresa, items):
    """Genera ticket como texto (para preview o impresora Windows)"""
    lineas = []
    w = 40  # Ancho en caracteres
    
    lineas.append("=" * w)
    lineas.append(empresa['nombre'].center(w))
    lineas.append(f"NIT: {empresa['nit']}".center(w))
    lineas.append(empresa['direccion'].center(w))
    lineas.append(f"Tel: {empresa['telefono']}".center(w))
    lineas.append("-" * w)
    lineas.append(f"Factura: {factura['numero']}")
    lineas.append(f"Fecha: {factura['fecha']} {factura['hora']}")
    lineas.append(f"Cliente: {factura['cliente']}")
    lineas.append("=" * w)
    
    for item in items:
        nombre = item['nombre'][:20]
        linea = f"{item['cantidad']:2d} {nombre:<20} ${item['total']:>10,.0f}".replace(',', '.')
        lineas.append(linea)
    
    lineas.append("-" * w)
    lineas.append(f"{'Subtotal:':<25} ${factura['subtotal']:>12,.0f}".replace(',', '.'))
    if factura.get('descuento', 0) > 0:
        lineas.append(f"{'Descuento:':<25} ${factura['descuento']:>12,.0f}".replace(',', '.'))
    lineas.append(f"{'IVA:':<25} ${factura['iva']:>12,.0f}".replace(',', '.'))
    lineas.append(f"{'TOTAL:':<25} ${factura['total']:>12,.0f}".replace(',', '.'))
    lineas.append("-" * w)
    lineas.append(f"Método de pago: {factura['metodo_pago']}")
    lineas.append("=" * w)
    lineas.append("¡Gracias por su compra!".center(w))
    lineas.append("")
    
    return "\n".join(lineas)
