# coding: utf-8
"""
RALOZ COL SAS - Sistema de Facturación v2.0
Base de Datos Completa
"""
import sqlite3
import bcrypt
import os

def inicializar_db(db_path="data/raloz.db"):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    
    # ==================== USUARIOS ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS usuarios (
        id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario TEXT UNIQUE NOT NULL,
        contraseña_hash TEXT NOT NULL,
        nombre_completo TEXT,
        rol TEXT DEFAULT 'vendedor',
        activo INTEGER DEFAULT 1,
        ultimo_acceso TEXT,
        fecha_creacion TEXT DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # ==================== CLIENTES ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS clientes (
        id_cliente INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo_documento TEXT DEFAULT 'CC',
        numero_documento TEXT UNIQUE,
        nombre TEXT NOT NULL,
        telefono TEXT,
        email TEXT,
        direccion TEXT,
        ciudad TEXT,
        notas TEXT,
        credito_limite REAL DEFAULT 0,
        credito_usado REAL DEFAULT 0,
        descuento_preferencial REAL DEFAULT 0,
        activo INTEGER DEFAULT 1,
        fecha_registro TEXT DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # ==================== CATEGORIAS ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS categorias (
        id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        descripcion TEXT,
        color TEXT DEFAULT '#1976D2',
        activo INTEGER DEFAULT 1
    )''')
    
    # ==================== PRODUCTOS ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS productos (
        id_producto INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo TEXT UNIQUE,
        codigo_barras TEXT,
        nombre TEXT NOT NULL,
        descripcion TEXT,
        id_categoria INTEGER,
        imagen_path TEXT,
        precio_costo REAL DEFAULT 0,
        precio_venta REAL DEFAULT 0,
        iva_porcentaje REAL DEFAULT 19,
        aplica_iva INTEGER DEFAULT 1,
        es_servicio INTEGER DEFAULT 0,
        activo INTEGER DEFAULT 1,
        fecha_creacion TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
    )''')
    
    # ==================== TALLAS (para uniformes) ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS tallas (
        id_talla INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        orden INTEGER DEFAULT 0
    )''')
    
    # ==================== INVENTARIO POR TALLA ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS inventario (
        id_inventario INTEGER PRIMARY KEY AUTOINCREMENT,
        id_producto INTEGER,
        id_talla INTEGER,
        stock_actual INTEGER DEFAULT 0,
        stock_minimo INTEGER DEFAULT 5,
        stock_maximo INTEGER DEFAULT 100,
        ubicacion TEXT,
        FOREIGN KEY (id_producto) REFERENCES productos(id_producto),
        FOREIGN KEY (id_talla) REFERENCES tallas(id_talla),
        UNIQUE(id_producto, id_talla)
    )''')
    
    # ==================== MOVIMIENTOS INVENTARIO ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS movimientos_inventario (
        id_movimiento INTEGER PRIMARY KEY AUTOINCREMENT,
        id_producto INTEGER,
        id_talla INTEGER,
        tipo TEXT,
        cantidad INTEGER,
        stock_anterior INTEGER,
        stock_nuevo INTEGER,
        motivo TEXT,
        referencia TEXT,
        usuario TEXT,
        fecha TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_producto) REFERENCES productos(id_producto)
    )''')
    
    # ==================== CAJAS ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS cajas (
        id_caja INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT DEFAULT 'Caja Principal',
        fecha_apertura TEXT,
        fecha_cierre TEXT,
        usuario_apertura TEXT,
        usuario_cierre TEXT,
        monto_inicial REAL DEFAULT 0,
        monto_ventas REAL DEFAULT 0,
        monto_devoluciones REAL DEFAULT 0,
        monto_gastos REAL DEFAULT 0,
        monto_final_sistema REAL DEFAULT 0,
        monto_final_real REAL DEFAULT 0,
        diferencia REAL DEFAULT 0,
        estado TEXT DEFAULT 'ABIERTA',
        observaciones TEXT
    )''')
    
    # ==================== MOVIMIENTOS CAJA ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS movimientos_caja (
        id_movimiento INTEGER PRIMARY KEY AUTOINCREMENT,
        id_caja INTEGER,
        tipo TEXT,
        concepto TEXT,
        valor REAL,
        metodo_pago TEXT,
        referencia TEXT,
        usuario TEXT,
        fecha TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_caja) REFERENCES cajas(id_caja)
    )''')
    
    # ==================== FACTURAS ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS facturas (
        id_factura INTEGER PRIMARY KEY AUTOINCREMENT,
        numero_factura TEXT UNIQUE,
        prefijo TEXT DEFAULT 'FV',
        fecha TEXT,
        hora TEXT,
        id_cliente INTEGER,
        subtotal REAL DEFAULT 0,
        descuento_porcentaje REAL DEFAULT 0,
        descuento_valor REAL DEFAULT 0,
        iva REAL DEFAULT 0,
        total REAL DEFAULT 0,
        metodo_pago TEXT,
        estado TEXT DEFAULT 'ACTIVA',
        notas TEXT,
        usuario TEXT,
        id_caja INTEGER,
        cufe TEXT,
        qr_dian TEXT,
        enviada_dian INTEGER DEFAULT 0,
        fecha_envio_dian TEXT,
        FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente),
        FOREIGN KEY (id_caja) REFERENCES cajas(id_caja)
    )''')
    
    # ==================== DETALLE FACTURAS ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS factura_detalle (
        id_detalle INTEGER PRIMARY KEY AUTOINCREMENT,
        id_factura INTEGER,
        id_producto INTEGER,
        id_talla INTEGER,
        descripcion TEXT,
        cantidad INTEGER,
        precio_unitario REAL,
        descuento REAL DEFAULT 0,
        iva REAL DEFAULT 0,
        total_linea REAL,
        FOREIGN KEY (id_factura) REFERENCES facturas(id_factura),
        FOREIGN KEY (id_producto) REFERENCES productos(id_producto)
    )''')
    
    # ==================== COTIZACIONES ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS cotizaciones (
        id_cotizacion INTEGER PRIMARY KEY AUTOINCREMENT,
        numero_cotizacion TEXT UNIQUE,
        fecha TEXT,
        vigencia_dias INTEGER DEFAULT 30,
        id_cliente INTEGER,
        subtotal REAL DEFAULT 0,
        descuento REAL DEFAULT 0,
        iva REAL DEFAULT 0,
        total REAL DEFAULT 0,
        estado TEXT DEFAULT 'PENDIENTE',
        notas TEXT,
        usuario TEXT,
        convertida_factura INTEGER,
        FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
    )''')
    
    # ==================== DETALLE COTIZACIONES ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS cotizacion_detalle (
        id_detalle INTEGER PRIMARY KEY AUTOINCREMENT,
        id_cotizacion INTEGER,
        id_producto INTEGER,
        id_talla INTEGER,
        descripcion TEXT,
        cantidad INTEGER,
        precio_unitario REAL,
        descuento REAL DEFAULT 0,
        total_linea REAL,
        FOREIGN KEY (id_cotizacion) REFERENCES cotizaciones(id_cotizacion)
    )''')
    
    # ==================== NOTAS CREDITO ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS notas_credito (
        id_nota INTEGER PRIMARY KEY AUTOINCREMENT,
        numero_nota TEXT UNIQUE,
        fecha TEXT,
        id_factura_original INTEGER,
        id_cliente INTEGER,
        subtotal REAL DEFAULT 0,
        iva REAL DEFAULT 0,
        total REAL DEFAULT 0,
        motivo TEXT,
        estado TEXT DEFAULT 'ACTIVA',
        usuario TEXT,
        id_caja INTEGER,
        FOREIGN KEY (id_factura_original) REFERENCES facturas(id_factura),
        FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
    )''')
    
    # ==================== GASTOS ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS gastos (
        id_gasto INTEGER PRIMARY KEY AUTOINCREMENT,
        fecha TEXT,
        categoria TEXT,
        descripcion TEXT,
        valor REAL,
        metodo_pago TEXT,
        comprobante TEXT,
        usuario TEXT,
        id_caja INTEGER,
        FOREIGN KEY (id_caja) REFERENCES cajas(id_caja)
    )''')
    
    # ==================== PAGOS CLIENTES ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS pagos (
        id_pago INTEGER PRIMARY KEY AUTOINCREMENT,
        fecha TEXT,
        id_cliente INTEGER,
        id_factura INTEGER,
        valor REAL,
        metodo_pago TEXT,
        referencia TEXT,
        notas TEXT,
        usuario TEXT,
        id_caja INTEGER,
        FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente),
        FOREIGN KEY (id_factura) REFERENCES facturas(id_factura)
    )''')
    
    # ==================== SERIES ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS series (
        id_serie INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo TEXT UNIQUE,
        prefijo TEXT,
        siguiente_numero INTEGER DEFAULT 1,
        resolucion_dian TEXT,
        fecha_resolucion TEXT,
        rango_inicio INTEGER,
        rango_fin INTEGER
    )''')
    
    # ==================== CONFIGURACION ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS configuracion (
        clave TEXT PRIMARY KEY,
        valor TEXT,
        descripcion TEXT
    )''')
    
    # ==================== CATEGORIAS GASTOS ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS categorias_gastos (
        id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        activo INTEGER DEFAULT 1
    )''')
    
    # ==================== METODOS PAGO ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS metodos_pago (
        id_metodo INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        requiere_referencia INTEGER DEFAULT 0,
        activo INTEGER DEFAULT 1
    )''')
    
    # ==================== COLA SINCRONIZACION (offline/online) ====================
    cur.execute('''CREATE TABLE IF NOT EXISTS sync_queue (
        id_sync INTEGER PRIMARY KEY AUTOINCREMENT,
        entidad TEXT,
        id_local INTEGER,
        operacion TEXT,
        datos TEXT,
        intentos INTEGER DEFAULT 0,
        estado TEXT DEFAULT 'PENDIENTE',
        fecha_creacion TEXT DEFAULT CURRENT_TIMESTAMP,
        fecha_sync TEXT
    )''')
    
    # ==================== DATOS INICIALES ====================
    
    # Usuario admin
    cur.execute("SELECT COUNT(*) FROM usuarios")
    if cur.fetchone()[0] == 0:
        hash_pw = bcrypt.hashpw("1234".encode(), bcrypt.gensalt()).decode()
        cur.execute("INSERT INTO usuarios (usuario, contraseña_hash, nombre_completo, rol) VALUES (?,?,?,?)",
                   ("admin", hash_pw, "Administrador", "admin"))
        cur.execute("INSERT INTO usuarios (usuario, contraseña_hash, nombre_completo, rol) VALUES (?,?,?,?)",
                   ("vendedor", bcrypt.hashpw("1234".encode(), bcrypt.gensalt()).decode(), "Vendedor", "vendedor"))
    
    # Cliente por defecto
    cur.execute("SELECT COUNT(*) FROM clientes")
    if cur.fetchone()[0] == 0:
        cur.execute("INSERT INTO clientes (tipo_documento, numero_documento, nombre) VALUES (?,?,?)",
                   ("NIT", "222222222", "CONSUMIDOR FINAL"))
    
    # Categorías productos
    cur.execute("SELECT COUNT(*) FROM categorias")
    if cur.fetchone()[0] == 0:
        cats = [
            ('Camisas', 'Camisas escolares', '#1976D2'),
            ('Pantalones', 'Pantalones escolares', '#388E3C'),
            ('Faldas', 'Faldas escolares', '#E91E63'),
            ('Sudaderas', 'Sudaderas deportivas', '#FF5722'),
            ('Buzos', 'Buzos escolares', '#9C27B0'),
            ('Medias', 'Medias escolares', '#607D8B'),
            ('Accesorios', 'Corbatas, cinturones, etc', '#795548'),
        ]
        for nombre, desc, color in cats:
            cur.execute("INSERT INTO categorias (nombre, descripcion, color) VALUES (?,?,?)", (nombre, desc, color))
    
    # Tallas
    cur.execute("SELECT COUNT(*) FROM tallas")
    if cur.fetchone()[0] == 0:
        tallas = ['4', '6', '8', '10', '12', '14', '16', 'S', 'M', 'L', 'XL', 'XXL']
        for i, t in enumerate(tallas):
            cur.execute("INSERT INTO tallas (nombre, orden) VALUES (?,?)", (t, i))
    
    # Categorías gastos
    cur.execute("SELECT COUNT(*) FROM categorias_gastos")
    if cur.fetchone()[0] == 0:
        for cat in ['Servicios', 'Arriendo', 'Nómina', 'Insumos', 'Transporte', 'Publicidad', 'Otros']:
            cur.execute("INSERT INTO categorias_gastos (nombre) VALUES (?)", (cat,))
    
    # Métodos de pago
    cur.execute("SELECT COUNT(*) FROM metodos_pago")
    if cur.fetchone()[0] == 0:
        metodos = [
            ('Efectivo', 0),
            ('Tarjeta Débito', 1),
            ('Tarjeta Crédito', 1),
            ('Nequi', 1),
            ('Daviplata', 1),
            ('Transferencia', 1),
            ('Crédito', 0),
        ]
        for nombre, ref in metodos:
            cur.execute("INSERT INTO metodos_pago (nombre, requiere_referencia) VALUES (?,?)", (nombre, ref))
    
    # Series
    cur.execute("SELECT COUNT(*) FROM series")
    if cur.fetchone()[0] == 0:
        series = [
            ('FACTURA', 'FV', 1, None, None, None, None),
            ('COTIZACION', 'COT', 1, None, None, None, None),
            ('NOTA_CREDITO', 'NC', 1, None, None, None, None),
        ]
        for tipo, prefijo, num, res, fecha, ini, fin in series:
            cur.execute("INSERT INTO series (tipo, prefijo, siguiente_numero, resolucion_dian, fecha_resolucion, rango_inicio, rango_fin) VALUES (?,?,?,?,?,?,?)",
                       (tipo, prefijo, num, res, fecha, ini, fin))
    
    # Configuración
    cur.execute("SELECT COUNT(*) FROM configuracion")
    if cur.fetchone()[0] == 0:
        config = [
            ('empresa_nombre', 'RALOZ COL SAS', 'Nombre de la empresa'),
            ('empresa_nit', '900.XXX.XXX-X', 'NIT de la empresa'),
            ('empresa_direccion', 'Calle Principal #123', 'Dirección'),
            ('empresa_telefono', '(601) 123-4567', 'Teléfono'),
            ('empresa_email', 'info@raloz.com', 'Email'),
            ('empresa_ciudad', 'Bogotá D.C.', 'Ciudad'),
            ('iva_porcentaje', '19', 'IVA por defecto'),
            ('moneda', 'COP', 'Moneda'),
            ('impresora_activa', '0', 'Impresora térmica activa'),
            ('impresora_nombre', '', 'Nombre impresora'),
            ('stock_alerta_bajo', '5', 'Alerta stock bajo'),
        ]
        for clave, valor, desc in config:
            cur.execute("INSERT INTO configuracion (clave, valor, descripcion) VALUES (?,?,?)", (clave, valor, desc))
    
    conn.commit()
    conn.close()
    print("✅ Base de datos RALOZ v2.0 inicializada")

if __name__ == "__main__":
    inicializar_db()
