# coding: utf-8
"""RALOZ - Módulo de Clientes con Historial"""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
from utils.tema_corporativo import COLORES, FUENTES, BotonModerno, HeaderModerno
from utils.money_parser import format_money

class ClientesModule:
    def __init__(self, parent, usuario, db_path):
        self.parent = parent
        self.usuario = usuario
        self.db_path = db_path
        self._crear_interfaz()
    
    def _crear_interfaz(self):
        HeaderModerno(self.parent, titulo="CLIENTES", icono="👥", color=COLORES['azul']).pack(fill=tk.X)
        
        main = tk.Frame(self.parent, bg=COLORES['fondo_principal'])
        main.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Toolbar
        toolbar = tk.Frame(main, bg=COLORES['blanco'])
        toolbar.pack(fill=tk.X, pady=(0,15))
        
        tk.Label(toolbar, text="🔍", font=('Segoe UI', 14), bg=COLORES['blanco']).pack(side=tk.LEFT, padx=(15,5))
        self.entry_buscar = tk.Entry(toolbar, font=FUENTES['normal'], width=30)
        self.entry_buscar.pack(side=tk.LEFT, padx=5, pady=15, ipady=5)
        self.entry_buscar.bind('<KeyRelease>', lambda e: self._cargar_clientes())
        
        BotonModerno(toolbar, texto="Nuevo Cliente", icono="➕", estilo="exito",
                    comando=self._nuevo_cliente, ancho=150, alto=40).pack(side=tk.LEFT, padx=10)
        BotonModerno(toolbar, texto="Ver Historial", icono="📋", estilo="primario",
                    comando=self._ver_historial, ancho=140, alto=40).pack(side=tk.LEFT, padx=5)
        
        # Tabla
        tabla = tk.Frame(main, bg=COLORES['blanco'])
        tabla.pack(fill=tk.BOTH, expand=True)
        
        cols = ('id', 'documento', 'nombre', 'telefono', 'email', 'total_compras', 'ultima_compra')
        self.tree = ttk.Treeview(tabla, columns=cols, show='headings', height=18)
        
        for col, w, anchor in [('id', 50, 'center'), ('documento', 110, 'w'), ('nombre', 200, 'w'),
                              ('telefono', 100, 'w'), ('email', 150, 'w'), 
                              ('total_compras', 120, 'e'), ('ultima_compra', 100, 'center')]:
            self.tree.heading(col, text=col.upper().replace('_', ' '))
            self.tree.column(col, width=w, anchor=anchor)
        
        scroll = ttk.Scrollbar(tabla, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=15, pady=15)
        scroll.pack(side=tk.RIGHT, fill=tk.Y, pady=15)
        
        self.tree.bind('<Double-1>', lambda e: self._editar_cliente())
        
        self._cargar_clientes()
    
    def _cargar_clientes(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        buscar = self.entry_buscar.get().strip()
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            query = '''
                SELECT c.id_cliente, c.numero_documento, c.nombre, c.telefono, c.email,
                       COALESCE(SUM(f.total), 0) as total,
                       MAX(f.fecha) as ultima
                FROM clientes c
                LEFT JOIN facturas f ON c.id_cliente = f.id_cliente AND f.estado = 'ACTIVA'
                WHERE c.activo = 1
            '''
            
            if buscar:
                query += " AND (c.nombre LIKE ? OR c.numero_documento LIKE ? OR c.telefono LIKE ?)"
                query += " GROUP BY c.id_cliente ORDER BY c.nombre"
                cur.execute(query, (f'%{buscar}%', f'%{buscar}%', f'%{buscar}%'))
            else:
                query += " GROUP BY c.id_cliente ORDER BY c.nombre"
                cur.execute(query)
            
            for row in cur.fetchall():
                id_c, doc, nombre, tel, email, total, ultima = row
                self.tree.insert('', 'end', values=(
                    id_c, doc or '-', nombre, tel or '-', email or '-',
                    format_money(total), ultima or '-'
                ))
            
            conn.close()
        except Exception as e:
            print(f"Error: {e}")
    
    def _nuevo_cliente(self):
        dialog = tk.Toplevel(self.parent)
        dialog.title("Nuevo Cliente")
        dialog.geometry("450x500")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="👤 Nuevo Cliente", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['azul']).pack(pady=20)
        
        form = tk.Frame(dialog, bg=COLORES['blanco'])
        form.pack(fill=tk.X, padx=30)
        
        campos = {}
        
        # Tipo documento
        row = tk.Frame(form, bg=COLORES['blanco'])
        row.pack(fill=tk.X, pady=5)
        tk.Label(row, text="Tipo Doc:", font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=12, anchor='w').pack(side=tk.LEFT)
        campos['tipo_doc'] = ttk.Combobox(row, values=['CC', 'NIT', 'CE', 'TI', 'PP'], state='readonly', width=10)
        campos['tipo_doc'].current(0)
        campos['tipo_doc'].pack(side=tk.LEFT)
        
        for label, key in [('Documento:', 'documento'), ('Nombre:', 'nombre'),
                          ('Teléfono:', 'telefono'), ('Email:', 'email'),
                          ('Dirección:', 'direccion'), ('Ciudad:', 'ciudad')]:
            row = tk.Frame(form, bg=COLORES['blanco'])
            row.pack(fill=tk.X, pady=5)
            tk.Label(row, text=label, font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=12, anchor='w').pack(side=tk.LEFT)
            campos[key] = tk.Entry(row, font=FUENTES['normal'])
            campos[key].pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        def guardar():
            try:
                nombre = campos['nombre'].get().strip()
                if not nombre:
                    messagebox.showwarning("Error", "El nombre es obligatorio")
                    return
                
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                cur.execute('''
                    INSERT INTO clientes (tipo_documento, numero_documento, nombre, telefono, email, direccion, ciudad)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    campos['tipo_doc'].get(),
                    campos['documento'].get().strip() or None,
                    nombre,
                    campos['telefono'].get().strip() or None,
                    campos['email'].get().strip() or None,
                    campos['direccion'].get().strip() or None,
                    campos['ciudad'].get().strip() or None
                ))
                conn.commit()
                conn.close()
                
                messagebox.showinfo("✅", "Cliente creado correctamente")
                dialog.destroy()
                self._cargar_clientes()
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "Ya existe un cliente con ese documento")
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        BotonModerno(dialog, texto="Guardar", icono="💾", estilo="exito",
                    comando=guardar, ancho=150, alto=45).pack(pady=20)
    
    def _editar_cliente(self):
        sel = self.tree.selection()
        if not sel:
            return
        
        item = self.tree.item(sel[0])['values']
        id_cliente = item[0]
        
        # Cargar datos del cliente
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT * FROM clientes WHERE id_cliente = ?", (id_cliente,))
            cliente = cur.fetchone()
            conn.close()
            
            if cliente:
                dialog = tk.Toplevel(self.parent)
                dialog.title("Editar Cliente")
                dialog.geometry("450x500")
                dialog.configure(bg=COLORES['blanco'])
                dialog.transient(self.parent)
                dialog.grab_set()
                
                tk.Label(dialog, text="✏️ Editar Cliente", font=FUENTES['header'],
                        bg=COLORES['blanco'], fg=COLORES['azul']).pack(pady=20)
                
                form = tk.Frame(dialog, bg=COLORES['blanco'])
                form.pack(fill=tk.X, padx=30)
                
                campos = {}
                datos = {'documento': cliente[2], 'nombre': cliente[3], 'telefono': cliente[4],
                        'email': cliente[5], 'direccion': cliente[6], 'ciudad': cliente[7]}
                
                for label, key in [('Documento:', 'documento'), ('Nombre:', 'nombre'),
                                  ('Teléfono:', 'telefono'), ('Email:', 'email'),
                                  ('Dirección:', 'direccion'), ('Ciudad:', 'ciudad')]:
                    row = tk.Frame(form, bg=COLORES['blanco'])
                    row.pack(fill=tk.X, pady=5)
                    tk.Label(row, text=label, font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=12, anchor='w').pack(side=tk.LEFT)
                    campos[key] = tk.Entry(row, font=FUENTES['normal'])
                    campos[key].pack(side=tk.LEFT, fill=tk.X, expand=True)
                    if datos.get(key):
                        campos[key].insert(0, datos[key])
                
                def guardar():
                    try:
                        conn = sqlite3.connect(self.db_path)
                        cur = conn.cursor()
                        cur.execute('''
                            UPDATE clientes SET numero_documento=?, nombre=?, telefono=?, email=?, direccion=?, ciudad=?
                            WHERE id_cliente=?
                        ''', (
                            campos['documento'].get().strip() or None,
                            campos['nombre'].get().strip(),
                            campos['telefono'].get().strip() or None,
                            campos['email'].get().strip() or None,
                            campos['direccion'].get().strip() or None,
                            campos['ciudad'].get().strip() or None,
                            id_cliente
                        ))
                        conn.commit()
                        conn.close()
                        messagebox.showinfo("✅", "Cliente actualizado")
                        dialog.destroy()
                        self._cargar_clientes()
                    except Exception as e:
                        messagebox.showerror("Error", str(e))
                
                BotonModerno(dialog, texto="Guardar", icono="💾", estilo="exito",
                            comando=guardar, ancho=150, alto=45).pack(pady=20)
        except Exception as e:
            messagebox.showerror("Error", str(e))
    
    def _ver_historial(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Seleccione", "Seleccione un cliente")
            return
        
        item = self.tree.item(sel[0])['values']
        id_cliente = item[0]
        nombre = item[2]
        
        dialog = tk.Toplevel(self.parent)
        dialog.title(f"Historial - {nombre}")
        dialog.geometry("700x500")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        
        tk.Label(dialog, text=f"📋 Historial de {nombre}", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['azul']).pack(pady=15)
        
        cols = ('factura', 'fecha', 'total', 'estado')
        tree = ttk.Treeview(dialog, columns=cols, show='headings', height=15)
        
        for col, w in [('factura', 120), ('fecha', 100), ('total', 120), ('estado', 100)]:
            tree.heading(col, text=col.upper())
            tree.column(col, width=w)
        
        tree.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute('''
                SELECT numero_factura, fecha, total, estado
                FROM facturas WHERE id_cliente = ?
                ORDER BY fecha DESC, id_factura DESC
            ''', (id_cliente,))
            
            for row in cur.fetchall():
                tree.insert('', 'end', values=(row[0], row[1], format_money(row[2]), row[3]))
            
            conn.close()
        except:
            pass
