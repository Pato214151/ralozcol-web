# coding: utf-8
"""RALOZ - Módulo de Configuración"""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import bcrypt
from utils.tema_corporativo import COLORES, FUENTES, BotonModerno, HeaderModerno

class ConfigModule:
    def __init__(self, parent, usuario, db_path):
        self.parent = parent
        self.usuario = usuario
        self.db_path = db_path
        self._crear_interfaz()
    
    def _crear_interfaz(self):
        HeaderModerno(self.parent, titulo="CONFIGURACIÓN", icono="⚙️", color=COLORES['gris_oscuro']).pack(fill=tk.X)
        
        main = tk.Frame(self.parent, bg=COLORES['fondo_principal'])
        main.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Notebook
        notebook = ttk.Notebook(main)
        notebook.pack(fill=tk.BOTH, expand=True)
        
        # Tab Empresa
        tab_empresa = tk.Frame(notebook, bg=COLORES['blanco'])
        notebook.add(tab_empresa, text="🏢 Empresa")
        self._crear_tab_empresa(tab_empresa)
        
        # Tab Usuarios
        tab_usuarios = tk.Frame(notebook, bg=COLORES['blanco'])
        notebook.add(tab_usuarios, text="👥 Usuarios")
        self._crear_tab_usuarios(tab_usuarios)
        
        # Tab Categorías
        tab_categorias = tk.Frame(notebook, bg=COLORES['blanco'])
        notebook.add(tab_categorias, text="📁 Categorías")
        self._crear_tab_categorias(tab_categorias)
        
        # Tab Series
        tab_series = tk.Frame(notebook, bg=COLORES['blanco'])
        notebook.add(tab_series, text="🔢 Series")
        self._crear_tab_series(tab_series)
    
    def _crear_tab_empresa(self, parent):
        form = tk.Frame(parent, bg=COLORES['blanco'])
        form.pack(fill=tk.BOTH, expand=True, padx=40, pady=30)
        
        tk.Label(form, text="Datos de la Empresa", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['azul']).pack(anchor='w', pady=(0,20))
        
        self.campos_empresa = {}
        
        campos = [
            ('empresa_nombre', 'Nombre Empresa:'),
            ('empresa_nit', 'NIT:'),
            ('empresa_direccion', 'Dirección:'),
            ('empresa_telefono', 'Teléfono:'),
            ('empresa_email', 'Email:'),
            ('empresa_ciudad', 'Ciudad:'),
        ]
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT clave, valor FROM configuracion")
            config = {r[0]: r[1] for r in cur.fetchall()}
            conn.close()
        except:
            config = {}
        
        for clave, label in campos:
            row = tk.Frame(form, bg=COLORES['blanco'])
            row.pack(fill=tk.X, pady=8)
            tk.Label(row, text=label, font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=18, anchor='w').pack(side=tk.LEFT)
            entry = tk.Entry(row, font=FUENTES['normal'], width=40)
            entry.pack(side=tk.LEFT, ipady=5)
            entry.insert(0, config.get(clave, ''))
            self.campos_empresa[clave] = entry
        
        BotonModerno(form, texto="Guardar Cambios", icono="💾", estilo="exito",
                    comando=self._guardar_empresa, ancho=180, alto=45).pack(pady=30)
    
    def _guardar_empresa(self):
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            for clave, entry in self.campos_empresa.items():
                cur.execute("UPDATE configuracion SET valor=? WHERE clave=?", (entry.get(), clave))
            
            conn.commit()
            conn.close()
            messagebox.showinfo("✅", "Configuración guardada")
        except Exception as e:
            messagebox.showerror("Error", str(e))
    
    def _crear_tab_usuarios(self, parent):
        toolbar = tk.Frame(parent, bg=COLORES['blanco'])
        toolbar.pack(fill=tk.X, padx=20, pady=15)
        
        BotonModerno(toolbar, texto="Nuevo Usuario", icono="➕", estilo="exito",
                    comando=self._nuevo_usuario, ancho=150, alto=40).pack(side=tk.LEFT)
        
        cols = ('id', 'usuario', 'nombre', 'rol', 'activo')
        self.tree_usuarios = ttk.Treeview(parent, columns=cols, show='headings', height=12)
        
        for col, w in [('id', 50), ('usuario', 120), ('nombre', 200), ('rol', 100), ('activo', 80)]:
            self.tree_usuarios.heading(col, text=col.upper())
            self.tree_usuarios.column(col, width=w)
        
        self.tree_usuarios.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0,20))
        self.tree_usuarios.bind('<Double-1>', self._editar_usuario)
        
        self._cargar_usuarios()
    
    def _cargar_usuarios(self):
        for item in self.tree_usuarios.get_children():
            self.tree_usuarios.delete(item)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT id_usuario, usuario, nombre_completo, rol, activo FROM usuarios")
            
            for row in cur.fetchall():
                self.tree_usuarios.insert('', 'end', values=(
                    row[0], row[1], row[2], row[3], '✅' if row[4] else '❌'
                ))
            
            conn.close()
        except:
            pass
    
    def _nuevo_usuario(self):
        dialog = tk.Toplevel(self.parent)
        dialog.title("Nuevo Usuario")
        dialog.geometry("400x400")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="👤 Nuevo Usuario", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['azul']).pack(pady=20)
        
        form = tk.Frame(dialog, bg=COLORES['blanco'])
        form.pack(padx=30)
        
        campos = {}
        for label, key in [('Usuario:', 'usuario'), ('Nombre:', 'nombre'), ('Contraseña:', 'password')]:
            row = tk.Frame(form, bg=COLORES['blanco'])
            row.pack(fill=tk.X, pady=8)
            tk.Label(row, text=label, font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=12, anchor='w').pack(side=tk.LEFT)
            entry = tk.Entry(form, font=FUENTES['normal'], show='●' if key == 'password' else '')
            entry.pack(fill=tk.X, pady=2)
            campos[key] = entry
        
        tk.Label(form, text="Rol:", font=FUENTES['normal_bold'], bg=COLORES['blanco']).pack(anchor='w', pady=(10,0))
        campos['rol'] = ttk.Combobox(form, values=['admin', 'vendedor'], state='readonly')
        campos['rol'].current(1)
        campos['rol'].pack(fill=tk.X, pady=5)
        
        def guardar():
            try:
                usuario = campos['usuario'].get().strip()
                nombre = campos['nombre'].get().strip()
                password = campos['password'].get()
                rol = campos['rol'].get()
                
                if not usuario or not password:
                    messagebox.showwarning("Error", "Usuario y contraseña son obligatorios")
                    return
                
                hash_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
                
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                cur.execute("INSERT INTO usuarios (usuario, contraseña_hash, nombre_completo, rol) VALUES (?,?,?,?)",
                           (usuario, hash_pw, nombre, rol))
                conn.commit()
                conn.close()
                
                messagebox.showinfo("✅", "Usuario creado")
                dialog.destroy()
                self._cargar_usuarios()
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "El usuario ya existe")
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        BotonModerno(dialog, texto="Crear Usuario", icono="💾", estilo="exito",
                    comando=guardar, ancho=150, alto=45).pack(pady=20)
    
    def _editar_usuario(self, event):
        sel = self.tree_usuarios.selection()
        if not sel:
            return
        
        item = self.tree_usuarios.item(sel[0])['values']
        messagebox.showinfo("Editar", f"Editar usuario: {item[1]}\n(En desarrollo)")
    
    def _crear_tab_categorias(self, parent):
        toolbar = tk.Frame(parent, bg=COLORES['blanco'])
        toolbar.pack(fill=tk.X, padx=20, pady=15)
        
        BotonModerno(toolbar, texto="Nueva Categoría", icono="➕", estilo="exito",
                    comando=self._nueva_categoria, ancho=160, alto=40).pack(side=tk.LEFT)
        
        cols = ('id', 'nombre', 'descripcion', 'activo')
        self.tree_categorias = ttk.Treeview(parent, columns=cols, show='headings', height=12)
        
        for col, w in [('id', 50), ('nombre', 150), ('descripcion', 250), ('activo', 80)]:
            self.tree_categorias.heading(col, text=col.upper())
            self.tree_categorias.column(col, width=w)
        
        self.tree_categorias.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0,20))
        
        self._cargar_categorias()
    
    def _cargar_categorias(self):
        for item in self.tree_categorias.get_children():
            self.tree_categorias.delete(item)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT id_categoria, nombre, descripcion, activo FROM categorias")
            
            for row in cur.fetchall():
                self.tree_categorias.insert('', 'end', values=(
                    row[0], row[1], row[2] or '', '✅' if row[3] else '❌'
                ))
            
            conn.close()
        except:
            pass
    
    def _nueva_categoria(self):
        dialog = tk.Toplevel(self.parent)
        dialog.title("Nueva Categoría")
        dialog.geometry("400x250")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="📁 Nueva Categoría", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['azul']).pack(pady=20)
        
        form = tk.Frame(dialog, bg=COLORES['blanco'])
        form.pack(padx=30)
        
        tk.Label(form, text="Nombre:", font=FUENTES['normal_bold'], bg=COLORES['blanco']).pack(anchor='w')
        entry_nombre = tk.Entry(form, font=FUENTES['normal'], width=30)
        entry_nombre.pack(pady=5)
        entry_nombre.focus()
        
        tk.Label(form, text="Descripción:", font=FUENTES['normal_bold'], bg=COLORES['blanco']).pack(anchor='w', pady=(10,0))
        entry_desc = tk.Entry(form, font=FUENTES['normal'], width=30)
        entry_desc.pack(pady=5)
        
        def guardar():
            try:
                nombre = entry_nombre.get().strip()
                if not nombre:
                    messagebox.showwarning("Error", "El nombre es obligatorio")
                    return
                
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                cur.execute("INSERT INTO categorias (nombre, descripcion) VALUES (?,?)",
                           (nombre, entry_desc.get().strip()))
                conn.commit()
                conn.close()
                
                messagebox.showinfo("✅", "Categoría creada")
                dialog.destroy()
                self._cargar_categorias()
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        BotonModerno(dialog, texto="Guardar", icono="💾", estilo="exito",
                    comando=guardar, ancho=120, alto=40).pack(pady=20)
    
    def _crear_tab_series(self, parent):
        info = tk.Label(parent, text="Configuración de series de facturación y resolución DIAN",
                       font=FUENTES['normal'], bg=COLORES['blanco'], fg=COLORES['gris_oscuro'])
        info.pack(pady=20)
        
        cols = ('tipo', 'prefijo', 'siguiente', 'resolucion')
        tree = ttk.Treeview(parent, columns=cols, show='headings', height=8)
        
        for col, w in [('tipo', 150), ('prefijo', 100), ('siguiente', 100), ('resolucion', 200)]:
            tree.heading(col, text=col.upper())
            tree.column(col, width=w)
        
        tree.pack(fill=tk.X, padx=20, pady=10)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT tipo, prefijo, siguiente_numero, resolucion_dian FROM series")
            
            for row in cur.fetchall():
                tree.insert('', 'end', values=(row[0], row[1], row[2], row[3] or 'Sin resolución'))
            
            conn.close()
        except:
            pass
