# coding: utf-8
"""RALOZ - Catálogo de Productos Visual"""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from utils.tema_corporativo import COLORES, FUENTES, BotonModerno, HeaderModerno
from utils.money_parser import format_money

class CatalogoModule:
    def __init__(self, parent, usuario, db_path):
        self.parent = parent
        self.usuario = usuario
        self.db_path = db_path
        self._crear_interfaz()
    
    def _crear_interfaz(self):
        HeaderModerno(self.parent, titulo="CATÁLOGO", icono="📦", color=COLORES['amarillo']).pack(fill=tk.X)
        
        main = tk.Frame(self.parent, bg=COLORES['fondo_principal'])
        main.pack(fill=tk.BOTH, expand=True)
        
        # Toolbar
        toolbar = tk.Frame(main, bg=COLORES['blanco'])
        toolbar.pack(fill=tk.X, padx=20, pady=15)
        
        tk.Label(toolbar, text="🔍", font=('Segoe UI', 14), bg=COLORES['blanco']).pack(side=tk.LEFT, padx=(15,5))
        self.entry_buscar = tk.Entry(toolbar, font=FUENTES['normal'], width=30)
        self.entry_buscar.pack(side=tk.LEFT, padx=5, ipady=5)
        self.entry_buscar.bind('<KeyRelease>', lambda e: self._cargar_productos())
        
        tk.Label(toolbar, text="Categoría:", font=FUENTES['normal'], bg=COLORES['blanco']).pack(side=tk.LEFT, padx=(15,5))
        self.combo_cat = ttk.Combobox(toolbar, state='readonly', width=15)
        self.combo_cat.pack(side=tk.LEFT)
        self.combo_cat.bind('<<ComboboxSelected>>', lambda e: self._cargar_productos())
        self._cargar_categorias()
        
        BotonModerno(toolbar, texto="Nuevo Producto", icono="➕", estilo="exito",
                    comando=self._nuevo_producto, ancho=160, alto=40).pack(side=tk.RIGHT, padx=15)
        
        # Grid de productos con scroll
        container = tk.Frame(main, bg=COLORES['fondo_principal'])
        container.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0,20))
        
        canvas = tk.Canvas(container, bg=COLORES['fondo_principal'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        self.frame_productos = tk.Frame(canvas, bg=COLORES['fondo_principal'])
        
        self.frame_productos.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.frame_productos, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind mouse wheel
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))
        
        self._cargar_productos()
    
    def _cargar_categorias(self):
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT nombre FROM categorias WHERE activo=1 ORDER BY nombre")
            cats = ['Todas'] + [r[0] for r in cur.fetchall()]
            conn.close()
            self.combo_cat['values'] = cats
            self.combo_cat.current(0)
        except:
            self.combo_cat['values'] = ['Todas']
    
    def _cargar_productos(self):
        for w in self.frame_productos.winfo_children():
            w.destroy()
        
        buscar = self.entry_buscar.get().strip()
        cat = self.combo_cat.get()
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            query = '''
                SELECT p.id_producto, p.codigo, p.nombre, p.precio_venta, c.nombre, c.color,
                       COALESCE(SUM(i.stock_actual), 0) as stock
                FROM productos p
                LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
                LEFT JOIN inventario i ON p.id_producto = i.id_producto
                WHERE p.activo = 1
            '''
            params = []
            
            if cat and cat != 'Todas':
                query += " AND c.nombre = ?"
                params.append(cat)
            
            if buscar:
                query += " AND (p.nombre LIKE ? OR p.codigo LIKE ?)"
                params.extend([f'%{buscar}%', f'%{buscar}%'])
            
            query += " GROUP BY p.id_producto ORDER BY p.nombre LIMIT 60"
            cur.execute(query, params)
            productos = cur.fetchall()
            conn.close()
            
            col = 0
            row = 0
            for prod in productos:
                self._crear_tarjeta(row, col, prod)
                col += 1
                if col >= 5:
                    col = 0
                    row += 1
            
            if not productos:
                tk.Label(self.frame_productos, text="No se encontraron productos",
                        font=FUENTES['normal'], bg=COLORES['fondo_principal'],
                        fg=COLORES['gris_oscuro']).grid(row=0, column=0, pady=50)
        except Exception as e:
            print(f"Error: {e}")
    
    def _crear_tarjeta(self, row, col, prod):
        id_p, codigo, nombre, precio, cat, color, stock = prod
        
        card = tk.Frame(self.frame_productos, bg=COLORES['blanco'],
                       highlightthickness=1, highlightbackground=COLORES['gris'],
                       cursor='hand2')
        card.grid(row=row, column=col, padx=10, pady=10, sticky='nsew')
        
        # Icono con color de categoría
        img_frame = tk.Frame(card, bg=color or COLORES['gris_claro'], width=110, height=90)
        img_frame.pack(padx=10, pady=10)
        img_frame.pack_propagate(False)
        tk.Label(img_frame, text="👔", font=('Segoe UI', 36), bg=color or COLORES['gris_claro']).pack(expand=True)
        
        # Código
        if codigo:
            tk.Label(card, text=codigo, font=FUENTES['pequeña'],
                    bg=COLORES['blanco'], fg=COLORES['gris_medio']).pack()
        
        # Nombre
        tk.Label(card, text=nombre[:20], font=FUENTES['normal_bold'],
                bg=COLORES['blanco']).pack()
        
        # Categoría
        tk.Label(card, text=cat or 'Sin categoría', font=FUENTES['pequeña'],
                bg=COLORES['blanco'], fg=COLORES['gris_oscuro']).pack()
        
        # Precio
        tk.Label(card, text=format_money(precio), font=FUENTES['grande'],
                bg=COLORES['blanco'], fg=COLORES['azul']).pack(pady=5)
        
        # Stock
        color_stock = COLORES['exito'] if stock > 5 else COLORES['rojo'] if stock > 0 else COLORES['gris_medio']
        estado = f"Stock: {int(stock)}" if stock > 0 else "AGOTADO"
        tk.Label(card, text=estado, font=FUENTES['pequeña'],
                bg=COLORES['blanco'], fg=color_stock).pack(pady=(0,10))
        
        # Eventos hover
        def on_enter(e):
            card.configure(highlightbackground=COLORES['azul'], highlightthickness=2)
        def on_leave(e):
            card.configure(highlightbackground=COLORES['gris'], highlightthickness=1)
        def on_click(e):
            self._editar_producto(id_p)
        
        card.bind('<Enter>', on_enter)
        card.bind('<Leave>', on_leave)
        card.bind('<Button-1>', on_click)
        for child in card.winfo_children():
            child.bind('<Button-1>', on_click)
    
    def _nuevo_producto(self):
        dialog = tk.Toplevel(self.parent)
        dialog.title("Nuevo Producto")
        dialog.geometry("500x550")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="➕ Nuevo Producto", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['azul']).pack(pady=20)
        
        form = tk.Frame(dialog, bg=COLORES['blanco'])
        form.pack(fill=tk.X, padx=40)
        
        campos = {}
        for label, key in [('Código:', 'codigo'), ('Código Barras:', 'codigo_barras'),
                          ('Nombre:', 'nombre'), ('Precio Costo:', 'precio_costo'),
                          ('Precio Venta:', 'precio_venta')]:
            row = tk.Frame(form, bg=COLORES['blanco'])
            row.pack(fill=tk.X, pady=8)
            tk.Label(row, text=label, font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=14, anchor='w').pack(side=tk.LEFT)
            campos[key] = tk.Entry(row, font=FUENTES['normal'])
            campos[key].pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=3)
        
        # Categoría
        row = tk.Frame(form, bg=COLORES['blanco'])
        row.pack(fill=tk.X, pady=8)
        tk.Label(row, text="Categoría:", font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=14, anchor='w').pack(side=tk.LEFT)
        campos['categoria'] = ttk.Combobox(row, state='readonly', font=FUENTES['normal'])
        campos['categoria'].pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT id_categoria, nombre FROM categorias WHERE activo=1")
            self.cat_list = cur.fetchall()
            campos['categoria']['values'] = [c[1] for c in self.cat_list]
            if self.cat_list:
                campos['categoria'].current(0)
            conn.close()
        except:
            self.cat_list = []
        
        def guardar():
            try:
                nombre = campos['nombre'].get().strip()
                if not nombre:
                    messagebox.showwarning("Error", "El nombre es obligatorio")
                    return
                
                idx = campos['categoria'].current()
                id_cat = self.cat_list[idx][0] if idx >= 0 else None
                
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                cur.execute('''
                    INSERT INTO productos (codigo, codigo_barras, nombre, id_categoria, precio_costo, precio_venta)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    campos['codigo'].get().strip() or None,
                    campos['codigo_barras'].get().strip() or None,
                    nombre, id_cat,
                    float(campos['precio_costo'].get() or 0),
                    float(campos['precio_venta'].get() or 0)
                ))
                
                id_producto = cur.lastrowid
                
                cur.execute("SELECT id_talla FROM tallas")
                for (id_talla,) in cur.fetchall():
                    cur.execute("INSERT INTO inventario (id_producto, id_talla, stock_actual) VALUES (?, ?, 0)",
                               (id_producto, id_talla))
                
                conn.commit()
                conn.close()
                
                messagebox.showinfo("✅", "Producto creado")
                dialog.destroy()
                self._cargar_productos()
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        BotonModerno(dialog, texto="Guardar", icono="💾", estilo="exito",
                    comando=guardar, ancho=150, alto=45).pack(pady=25)
    
    def _editar_producto(self, id_producto):
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT * FROM productos WHERE id_producto = ?", (id_producto,))
            prod = cur.fetchone()
            conn.close()
            
            if prod:
                dialog = tk.Toplevel(self.parent)
                dialog.title(f"Editar: {prod[3]}")
                dialog.geometry("500x500")
                dialog.configure(bg=COLORES['blanco'])
                dialog.transient(self.parent)
                dialog.grab_set()
                
                tk.Label(dialog, text="✏️ Editar Producto", font=FUENTES['header'],
                        bg=COLORES['blanco'], fg=COLORES['azul']).pack(pady=20)
                
                form = tk.Frame(dialog, bg=COLORES['blanco'])
                form.pack(fill=tk.X, padx=40)
                
                campos = {}
                valores = {'codigo': prod[1], 'codigo_barras': prod[2], 'nombre': prod[3],
                          'precio_costo': prod[7], 'precio_venta': prod[8]}
                
                for label, key in [('Código:', 'codigo'), ('Código Barras:', 'codigo_barras'),
                                  ('Nombre:', 'nombre'), ('Precio Costo:', 'precio_costo'),
                                  ('Precio Venta:', 'precio_venta')]:
                    row = tk.Frame(form, bg=COLORES['blanco'])
                    row.pack(fill=tk.X, pady=8)
                    tk.Label(row, text=label, font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=14, anchor='w').pack(side=tk.LEFT)
                    campos[key] = tk.Entry(row, font=FUENTES['normal'])
                    campos[key].pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=3)
                    if valores.get(key):
                        campos[key].insert(0, str(valores[key]))
                
                def guardar():
                    try:
                        conn = sqlite3.connect(self.db_path)
                        cur = conn.cursor()
                        cur.execute('''
                            UPDATE productos SET codigo=?, codigo_barras=?, nombre=?, precio_costo=?, precio_venta=?
                            WHERE id_producto=?
                        ''', (
                            campos['codigo'].get().strip() or None,
                            campos['codigo_barras'].get().strip() or None,
                            campos['nombre'].get().strip(),
                            float(campos['precio_costo'].get() or 0),
                            float(campos['precio_venta'].get() or 0),
                            id_producto
                        ))
                        conn.commit()
                        conn.close()
                        messagebox.showinfo("✅", "Producto actualizado")
                        dialog.destroy()
                        self._cargar_productos()
                    except Exception as e:
                        messagebox.showerror("Error", str(e))
                
                BotonModerno(dialog, texto="Guardar", icono="💾", estilo="exito",
                            comando=guardar, ancho=150, alto=45).pack(pady=25)
        except Exception as e:
            messagebox.showerror("Error", str(e))
