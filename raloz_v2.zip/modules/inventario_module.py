# coding: utf-8
"""RALOZ - Módulo de Inventario con Alertas de Stock"""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
from utils.tema_corporativo import COLORES, FUENTES, BotonModerno, HeaderModerno
from utils.money_parser import format_money

class InventarioModule:
    def __init__(self, parent, usuario, db_path):
        self.parent = parent
        self.usuario = usuario
        self.db_path = db_path
        self._crear_interfaz()
    
    def _crear_interfaz(self):
        HeaderModerno(self.parent, titulo="INVENTARIO", icono="📋", color=COLORES['amarillo']).pack(fill=tk.X)
        
        main = tk.Frame(self.parent, bg=COLORES['fondo_principal'])
        main.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Alertas de stock bajo
        self._crear_alertas(main)
        
        # Toolbar
        toolbar = tk.Frame(main, bg=COLORES['blanco'])
        toolbar.pack(fill=tk.X, pady=(0,15))
        
        tk.Label(toolbar, text="🔍", font=('Segoe UI', 14), bg=COLORES['blanco']).pack(side=tk.LEFT, padx=(15,5))
        self.entry_buscar = tk.Entry(toolbar, font=FUENTES['normal'], width=30)
        self.entry_buscar.pack(side=tk.LEFT, padx=5, pady=15, ipady=5)
        self.entry_buscar.bind('<KeyRelease>', lambda e: self._cargar_inventario())
        
        BotonModerno(toolbar, texto="Nuevo Producto", icono="➕", estilo="exito",
                    comando=self._nuevo_producto, ancho=150, alto=40).pack(side=tk.LEFT, padx=10)
        BotonModerno(toolbar, texto="Ajustar Stock", icono="📦", estilo="primario",
                    comando=self._ajustar_stock, ancho=140, alto=40).pack(side=tk.LEFT, padx=5)
        BotonModerno(toolbar, texto="Entrada Masiva", icono="📥", estilo="secundario",
                    comando=self._entrada_masiva, ancho=150, alto=40).pack(side=tk.LEFT, padx=5)
        
        # Tabla de inventario
        tabla_frame = tk.Frame(main, bg=COLORES['blanco'])
        tabla_frame.pack(fill=tk.BOTH, expand=True)
        
        cols = ('id', 'codigo', 'producto', 'categoria', 'talla', 'stock', 'minimo', 'precio', 'estado')
        self.tree = ttk.Treeview(tabla_frame, columns=cols, show='headings', height=20)
        
        for col, w in [('id', 50), ('codigo', 80), ('producto', 200), ('categoria', 100),
                       ('talla', 60), ('stock', 70), ('minimo', 70), ('precio', 100), ('estado', 100)]:
            self.tree.heading(col, text=col.upper())
            self.tree.column(col, width=w, anchor='center' if col in ['stock', 'minimo', 'talla'] else 'w')
        
        scroll_y = ttk.Scrollbar(tabla_frame, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll_y.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=15, pady=15)
        scroll_y.pack(side=tk.RIGHT, fill=tk.Y, pady=15)
        
        self.tree.bind('<Double-1>', lambda e: self._editar_producto())
        
        # Tags para colores
        self.tree.tag_configure('bajo', background=COLORES['rojo_claro'])
        self.tree.tag_configure('agotado', background='#FFCDD2')
        self.tree.tag_configure('ok', background=COLORES['blanco'])
        
        self._cargar_inventario()
    
    def _crear_alertas(self, parent):
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute('''
                SELECT COUNT(*) FROM inventario 
                WHERE stock_actual <= stock_minimo AND stock_actual > 0
            ''')
            bajo = cur.fetchone()[0]
            
            cur.execute('SELECT COUNT(*) FROM inventario WHERE stock_actual = 0')
            agotado = cur.fetchone()[0]
            conn.close()
            
            if bajo > 0 or agotado > 0:
                alerta = tk.Frame(parent, bg=COLORES['rojo_claro'])
                alerta.pack(fill=tk.X, pady=(0,15))
                
                contenido = tk.Frame(alerta, bg=COLORES['rojo_claro'])
                contenido.pack(fill=tk.X, padx=20, pady=15)
                
                tk.Label(contenido, text="⚠️ ALERTAS DE STOCK", font=FUENTES['normal_bold'],
                        bg=COLORES['rojo_claro'], fg=COLORES['rojo']).pack(side=tk.LEFT)
                
                if agotado > 0:
                    tk.Label(contenido, text=f"🔴 {agotado} agotados", font=FUENTES['normal'],
                            bg=COLORES['rojo_claro'], fg=COLORES['rojo']).pack(side=tk.LEFT, padx=20)
                
                if bajo > 0:
                    tk.Label(contenido, text=f"🟡 {bajo} con stock bajo", font=FUENTES['normal'],
                            bg=COLORES['rojo_claro'], fg=COLORES['amarillo_hover']).pack(side=tk.LEFT, padx=10)
        except:
            pass
    
    def _cargar_inventario(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        buscar = self.entry_buscar.get().strip()
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            query = '''
                SELECT p.id_producto, p.codigo, p.nombre, c.nombre, t.nombre,
                       i.stock_actual, i.stock_minimo, p.precio_venta
                FROM productos p
                LEFT JOIN inventario i ON p.id_producto = i.id_producto
                LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
                LEFT JOIN tallas t ON i.id_talla = t.id_talla
                WHERE p.activo = 1
            '''
            
            if buscar:
                query += " AND (p.nombre LIKE ? OR p.codigo LIKE ?)"
                cur.execute(query + " ORDER BY p.nombre, t.orden", (f'%{buscar}%', f'%{buscar}%'))
            else:
                cur.execute(query + " ORDER BY p.nombre, t.orden")
            
            for row in cur.fetchall():
                id_p, codigo, nombre, cat, talla, stock, minimo, precio = row
                stock = stock or 0
                minimo = minimo or 5
                
                if stock == 0:
                    estado = '🔴 Agotado'
                    tag = 'agotado'
                elif stock <= minimo:
                    estado = '🟡 Bajo'
                    tag = 'bajo'
                else:
                    estado = '🟢 OK'
                    tag = 'ok'
                
                self.tree.insert('', 'end', values=(
                    id_p, codigo or '-', nombre, cat or '-', talla or '-',
                    stock, minimo, format_money(precio), estado
                ), tags=(tag,))
            
            conn.close()
        except Exception as e:
            print(f"Error: {e}")
    
    def _nuevo_producto(self):
        dialog = tk.Toplevel(self.parent)
        dialog.title("Nuevo Producto")
        dialog.geometry("500x600")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="➕ Nuevo Producto", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['azul']).pack(pady=20)
        
        form = tk.Frame(dialog, bg=COLORES['blanco'])
        form.pack(fill=tk.X, padx=30)
        
        campos = {}
        for label, key in [('Código:', 'codigo'), ('Código Barras:', 'codigo_barras'),
                          ('Nombre:', 'nombre'), ('Precio Costo:', 'precio_costo'),
                          ('Precio Venta:', 'precio_venta')]:
            row = tk.Frame(form, bg=COLORES['blanco'])
            row.pack(fill=tk.X, pady=5)
            tk.Label(row, text=label, font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=15, anchor='w').pack(side=tk.LEFT)
            campos[key] = tk.Entry(row, font=FUENTES['normal'])
            campos[key].pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Categoría
        row = tk.Frame(form, bg=COLORES['blanco'])
        row.pack(fill=tk.X, pady=5)
        tk.Label(row, text="Categoría:", font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=15, anchor='w').pack(side=tk.LEFT)
        campos['categoria'] = ttk.Combobox(row, state='readonly', font=FUENTES['normal'])
        campos['categoria'].pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Cargar categorías
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT id_categoria, nombre FROM categorias WHERE activo=1")
            self.categorias_list = cur.fetchall()
            campos['categoria']['values'] = [c[1] for c in self.categorias_list]
            if self.categorias_list:
                campos['categoria'].current(0)
            conn.close()
        except:
            pass
        
        def guardar():
            try:
                nombre = campos['nombre'].get().strip()
                if not nombre:
                    messagebox.showwarning("Error", "El nombre es obligatorio")
                    return
                
                idx = campos['categoria'].current()
                id_cat = self.categorias_list[idx][0] if idx >= 0 else None
                
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                cur.execute('''
                    INSERT INTO productos (codigo, codigo_barras, nombre, id_categoria, precio_costo, precio_venta)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    campos['codigo'].get().strip() or None,
                    campos['codigo_barras'].get().strip() or None,
                    nombre,
                    id_cat,
                    float(campos['precio_costo'].get() or 0),
                    float(campos['precio_venta'].get() or 0)
                ))
                
                id_producto = cur.lastrowid
                
                # Crear inventario para cada talla
                cur.execute("SELECT id_talla FROM tallas")
                for (id_talla,) in cur.fetchall():
                    cur.execute("INSERT INTO inventario (id_producto, id_talla, stock_actual) VALUES (?, ?, 0)",
                               (id_producto, id_talla))
                
                conn.commit()
                conn.close()
                
                messagebox.showinfo("✅", "Producto creado correctamente")
                dialog.destroy()
                self._cargar_inventario()
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        BotonModerno(dialog, texto="Guardar", icono="💾", estilo="exito",
                    comando=guardar, ancho=150, alto=45).pack(pady=20)
    
    def _editar_producto(self):
        sel = self.tree.selection()
        if not sel:
            return
        
        item = self.tree.item(sel[0])['values']
        id_producto = item[0]
        
        messagebox.showinfo("Editar", f"Editar producto ID: {id_producto}\n(Funcionalidad completa en desarrollo)")
    
    def _ajustar_stock(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Seleccione", "Seleccione un producto de la lista")
            return
        
        item = self.tree.item(sel[0])['values']
        id_producto = item[0]
        nombre = item[2]
        talla = item[4]
        stock_actual = item[5]
        
        dialog = tk.Toplevel(self.parent)
        dialog.title("Ajustar Stock")
        dialog.geometry("400x300")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="📦 Ajustar Stock", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['azul']).pack(pady=20)
        
        tk.Label(dialog, text=f"{nombre} - Talla {talla}", font=FUENTES['normal_bold'],
                bg=COLORES['blanco']).pack()
        tk.Label(dialog, text=f"Stock actual: {stock_actual}", font=FUENTES['normal'],
                bg=COLORES['blanco']).pack(pady=10)
        
        frame = tk.Frame(dialog, bg=COLORES['blanco'])
        frame.pack(pady=15)
        
        tk.Label(frame, text="Nuevo stock:", font=FUENTES['normal'], bg=COLORES['blanco']).pack(side=tk.LEFT)
        entry = tk.Entry(frame, font=('Segoe UI', 16), width=10, justify='center')
        entry.pack(side=tk.LEFT, padx=15)
        entry.insert(0, str(stock_actual))
        entry.select_range(0, tk.END)
        entry.focus()
        
        def guardar():
            try:
                nuevo = int(entry.get())
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                
                # Buscar el inventario correcto
                cur.execute('''
                    SELECT i.id_inventario, i.stock_actual FROM inventario i
                    JOIN tallas t ON i.id_talla = t.id_talla
                    WHERE i.id_producto = ? AND t.nombre = ?
                ''', (id_producto, talla))
                inv = cur.fetchone()
                
                if inv:
                    cur.execute("UPDATE inventario SET stock_actual = ? WHERE id_inventario = ?",
                               (nuevo, inv[0]))
                    
                    # Registrar movimiento
                    diferencia = nuevo - inv[1]
                    tipo = 'ENTRADA' if diferencia > 0 else 'SALIDA'
                    cur.execute('''
                        INSERT INTO movimientos_inventario 
                        (id_producto, id_talla, tipo, cantidad, stock_anterior, stock_nuevo, motivo, usuario)
                        VALUES (?, (SELECT id_talla FROM tallas WHERE nombre=?), ?, ?, ?, ?, 'Ajuste manual', ?)
                    ''', (id_producto, talla, tipo, abs(diferencia), inv[1], nuevo, self.usuario['usuario']))
                
                conn.commit()
                conn.close()
                
                messagebox.showinfo("✅", "Stock actualizado")
                dialog.destroy()
                self._cargar_inventario()
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        BotonModerno(dialog, texto="Guardar", icono="💾", estilo="exito",
                    comando=guardar, ancho=120, alto=40).pack(pady=15)
    
    def _entrada_masiva(self):
        messagebox.showinfo("Entrada Masiva", "Módulo de entrada masiva de inventario\n(En desarrollo)")
