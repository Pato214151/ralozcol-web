# coding: utf-8
"""RALOZ - Dashboard Principal con Gráficas"""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime, timedelta
from utils.tema_corporativo import (COLORES, FUENTES, BotonModerno, TarjetaKPI, 
                                     PanelLateral, HeaderModerno, aplicar_tema)
from utils.money_parser import format_money

# Importar matplotlib si está disponible
try:
    import matplotlib
    matplotlib.use('TkAgg')
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.figure import Figure
    MATPLOTLIB_DISPONIBLE = True
except ImportError:
    MATPLOTLIB_DISPONIBLE = False


class DashboardModule:
    def __init__(self, root, usuario, db_path, cambiar_modulo_callback):
        self.root = root
        self.usuario = usuario
        self.db_path = db_path
        self.cambiar_modulo = cambiar_modulo_callback
        
        self.root.title(f"RALOZ COL SAS - {usuario['nombre']}")
        
        for w in self.root.winfo_children():
            w.destroy()
        
        aplicar_tema(self.root)
        self._crear_interfaz()
        self._cargar_datos()
    
    def _crear_interfaz(self):
        # Container principal
        main_container = tk.Frame(self.root, bg=COLORES['fondo_principal'])
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Sidebar
        self.sidebar = PanelLateral(main_container)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.agregar_header("RALOZ", f"v2.0 | {self.usuario['rol'].upper()}")
        self.sidebar.agregar_separador()
        
        # Botones del menú
        menus = [
            ('dashboard', 'Dashboard', '📊', lambda: self._mostrar_dashboard()),
            ('pos', 'Punto de Venta', '🛒', lambda: self.cambiar_modulo('pos')),
            ('catalogo', 'Catálogo', '📦', lambda: self.cambiar_modulo('catalogo')),
            ('facturas', 'Facturación', '🧾', lambda: self.cambiar_modulo('facturas')),
            ('clientes', 'Clientes', '👥', lambda: self.cambiar_modulo('clientes')),
            ('inventario', 'Inventario', '📋', lambda: self.cambiar_modulo('inventario')),
            ('caja', 'Caja', '🏦', lambda: self.cambiar_modulo('caja')),
            ('reportes', 'Reportes', '📈', lambda: self.cambiar_modulo('reportes')),
        ]
        
        for key, texto, icono, cmd in menus:
            self.sidebar.agregar_boton(key, texto, icono, cmd)
        
        self.sidebar.agregar_separador()
        
        if self.usuario['rol'] == 'admin':
            self.sidebar.agregar_boton('config', 'Configuración', '⚙️', lambda: self.cambiar_modulo('config'))
        
        self.sidebar.agregar_boton('salir', 'Cerrar Sesión', '🚪', self._cerrar_sesion)
        
        self.sidebar.activar_boton('dashboard')
        
        # Área de contenido
        self.content_area = tk.Frame(main_container, bg=COLORES['fondo_principal'])
        self.content_area.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self._mostrar_dashboard()
    
    def _mostrar_dashboard(self):
        for w in self.content_area.winfo_children():
            w.destroy()
        
        self.sidebar.activar_boton('dashboard')
        
        # Header
        header = tk.Frame(self.content_area, bg=COLORES['azul'], height=70)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        
        h_content = tk.Frame(header, bg=COLORES['azul'])
        h_content.pack(fill=tk.BOTH, expand=True, padx=30)
        
        tk.Label(h_content, text="📊  Dashboard", font=FUENTES['titulo'],
                bg=COLORES['azul'], fg=COLORES['blanco']).pack(side=tk.LEFT, pady=15)
        
        tk.Label(h_content, text=datetime.now().strftime("%d/%m/%Y %H:%M"),
                font=FUENTES['normal'], bg=COLORES['azul'], fg=COLORES['amarillo']).pack(side=tk.RIGHT, pady=20)
        
        tk.Frame(header, bg=COLORES['amarillo'], height=4).pack(side=tk.BOTTOM, fill=tk.X)
        
        # Scroll area
        canvas = tk.Canvas(self.content_area, bg=COLORES['fondo_principal'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.content_area, orient="vertical", command=canvas.yview)
        scrollable = tk.Frame(canvas, bg=COLORES['fondo_principal'])
        
        scrollable.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # KPIs
        kpi_frame = tk.Frame(scrollable, bg=COLORES['fondo_principal'])
        kpi_frame.pack(fill=tk.X, padx=30, pady=20)
        
        self.kpi_ventas = TarjetaKPI(kpi_frame, titulo="Ventas Hoy", valor="$0", 
                                     icono="💰", color=COLORES['exito'], tendencia=12)
        self.kpi_ventas.pack(side=tk.LEFT, padx=10)
        self.kpi_ventas.configure(width=220, height=140)
        
        self.kpi_facturas = TarjetaKPI(kpi_frame, titulo="Facturas Hoy", valor="0",
                                        icono="🧾", color=COLORES['azul'])
        self.kpi_facturas.pack(side=tk.LEFT, padx=10)
        self.kpi_facturas.configure(width=220, height=140)
        
        self.kpi_clientes = TarjetaKPI(kpi_frame, titulo="Clientes", valor="0",
                                        icono="👥", color=COLORES['amarillo'])
        self.kpi_clientes.pack(side=tk.LEFT, padx=10)
        self.kpi_clientes.configure(width=220, height=140)
        
        self.kpi_stock = TarjetaKPI(kpi_frame, titulo="Alertas Stock", valor="0",
                                     icono="⚠️", color=COLORES['rojo'])
        self.kpi_stock.pack(side=tk.LEFT, padx=10)
        self.kpi_stock.configure(width=220, height=140)
        
        # Gráficas
        graficas_frame = tk.Frame(scrollable, bg=COLORES['fondo_principal'])
        graficas_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=10)
        
        if MATPLOTLIB_DISPONIBLE:
            self._crear_graficas(graficas_frame)
        else:
            tk.Label(graficas_frame, text="Instala matplotlib para ver gráficas:\npip install matplotlib",
                    font=FUENTES['normal'], bg=COLORES['blanco'], fg=COLORES['gris_oscuro'],
                    justify='center').pack(pady=50)
        
        # Acciones rápidas
        acciones = tk.Frame(scrollable, bg=COLORES['fondo_principal'])
        acciones.pack(fill=tk.X, padx=30, pady=20)
        
        tk.Label(acciones, text="⚡ Acciones Rápidas", font=FUENTES['header'],
                bg=COLORES['fondo_principal'], fg=COLORES['negro']).pack(anchor='w', pady=(0,15))
        
        btns = tk.Frame(acciones, bg=COLORES['fondo_principal'])
        btns.pack(fill=tk.X)
        
        BotonModerno(btns, texto="Nueva Venta", icono="🛒", estilo="exito",
                    comando=lambda: self.cambiar_modulo('pos'), ancho=160, alto=50).pack(side=tk.LEFT, padx=5)
        BotonModerno(btns, texto="Nueva Factura", icono="🧾", estilo="primario",
                    comando=lambda: self.cambiar_modulo('facturas'), ancho=160, alto=50).pack(side=tk.LEFT, padx=5)
        BotonModerno(btns, texto="Nuevo Cliente", icono="👤", estilo="secundario",
                    comando=lambda: self.cambiar_modulo('clientes'), ancho=160, alto=50).pack(side=tk.LEFT, padx=5)
        BotonModerno(btns, texto="Ver Reportes", icono="📈", estilo="oscuro",
                    comando=lambda: self.cambiar_modulo('reportes'), ancho=160, alto=50).pack(side=tk.LEFT, padx=5)
    
    def _crear_graficas(self, parent):
        # Frame para gráficas
        graf_container = tk.Frame(parent, bg=COLORES['blanco'])
        graf_container.pack(fill=tk.BOTH, expand=True)
        
        # Crear figura
        fig = Figure(figsize=(12, 4), facecolor=COLORES['blanco'])
        
        # Gráfica de ventas semanales
        ax1 = fig.add_subplot(1, 2, 1)
        dias = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']
        ventas = self._obtener_ventas_semana()
        
        bars = ax1.bar(dias, ventas, color=COLORES['azul'], edgecolor=COLORES['azul_hover'])
        ax1.set_title('Ventas de la Semana', fontsize=12, fontweight='bold', color=COLORES['negro'])
        ax1.set_ylabel('Ventas ($)', fontsize=10)
        ax1.tick_params(colors=COLORES['gris_oscuro'])
        ax1.spines['top'].set_visible(False)
        ax1.spines['right'].set_visible(False)
        
        # Formato de valores en el eje Y
        ax1.yaxis.set_major_formatter(lambda x, p: f'${x/1000:.0f}K')
        
        # Gráfica de productos más vendidos
        ax2 = fig.add_subplot(1, 2, 2)
        productos, cantidades = self._obtener_top_productos()
        
        colors = [COLORES['amarillo'], COLORES['azul'], COLORES['exito'], 
                  COLORES['rojo'], COLORES['gris_medio']]
        ax2.barh(productos, cantidades, color=colors[:len(productos)])
        ax2.set_title('Top 5 Productos', fontsize=12, fontweight='bold', color=COLORES['negro'])
        ax2.set_xlabel('Unidades Vendidas', fontsize=10)
        ax2.tick_params(colors=COLORES['gris_oscuro'])
        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_visible(False)
        
        fig.tight_layout(pad=3.0)
        
        # Agregar al frame
        canvas = FigureCanvasTkAgg(fig, master=graf_container)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
    
    def _obtener_ventas_semana(self):
        """Obtiene ventas de los últimos 7 días"""
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            ventas = []
            for i in range(6, -1, -1):
                fecha = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
                cur.execute("SELECT COALESCE(SUM(total), 0) FROM facturas WHERE fecha=? AND estado='ACTIVA'", (fecha,))
                ventas.append(cur.fetchone()[0])
            
            conn.close()
            return ventas
        except:
            return [0] * 7
    
    def _obtener_top_productos(self):
        """Obtiene los 5 productos más vendidos"""
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute('''
                SELECT p.nombre, SUM(d.cantidad) as total
                FROM factura_detalle d
                JOIN productos p ON d.id_producto = p.id_producto
                JOIN facturas f ON d.id_factura = f.id_factura
                WHERE f.estado = 'ACTIVA'
                GROUP BY p.id_producto
                ORDER BY total DESC
                LIMIT 5
            ''')
            rows = cur.fetchall()
            conn.close()
            
            if rows:
                productos = [r[0][:15] for r in rows]
                cantidades = [r[1] for r in rows]
                return productos, cantidades
            return ['Sin datos'], [0]
        except:
            return ['Sin datos'], [0]
    
    def _cargar_datos(self):
        """Carga datos para los KPIs"""
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            hoy = datetime.now().strftime('%Y-%m-%d')
            
            # Ventas hoy
            cur.execute("SELECT COALESCE(SUM(total), 0) FROM facturas WHERE fecha=? AND estado='ACTIVA'", (hoy,))
            ventas_hoy = cur.fetchone()[0]
            self.kpi_ventas.actualizar_valor(format_money(ventas_hoy))
            
            # Facturas hoy
            cur.execute("SELECT COUNT(*) FROM facturas WHERE fecha=? AND estado='ACTIVA'", (hoy,))
            facturas_hoy = cur.fetchone()[0]
            self.kpi_facturas.actualizar_valor(str(facturas_hoy))
            
            # Total clientes
            cur.execute("SELECT COUNT(*) FROM clientes WHERE activo=1")
            total_clientes = cur.fetchone()[0]
            self.kpi_clientes.actualizar_valor(str(total_clientes))
            
            # Alertas stock
            cur.execute("SELECT COUNT(*) FROM inventario WHERE stock_actual <= stock_minimo")
            alertas = cur.fetchone()[0]
            self.kpi_stock.actualizar_valor(str(alertas))
            
            conn.close()
        except Exception as e:
            print(f"Error cargando datos: {e}")
    
    def _cerrar_sesion(self):
        if messagebox.askyesno("Cerrar Sesión", "¿Desea cerrar sesión?"):
            self.root.destroy()
            import main
            main.iniciar_app()
