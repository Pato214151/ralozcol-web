# coding: utf-8
"""RALOZ - Módulo de Caja y Arqueo"""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
from utils.tema_corporativo import COLORES, FUENTES, BotonModerno, HeaderModerno, TarjetaKPI
from utils.money_parser import format_money, parse_money

class CajaModule:
    def __init__(self, parent, usuario, db_path):
        self.parent = parent
        self.usuario = usuario
        self.db_path = db_path
        self._crear_interfaz()
        self._verificar_estado_caja()
    
    def _crear_interfaz(self):
        HeaderModerno(self.parent, titulo="CAJA", icono="🏦", color=COLORES['negro']).pack(fill=tk.X)
        
        main = tk.Frame(self.parent, bg=COLORES['fondo_principal'])
        main.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Estado de caja
        self.estado_frame = tk.Frame(main, bg=COLORES['blanco'])
        self.estado_frame.pack(fill=tk.X, pady=(0,15))
        
        # KPIs
        kpi_frame = tk.Frame(main, bg=COLORES['fondo_principal'])
        kpi_frame.pack(fill=tk.X, pady=(0,15))
        
        self.kpi_ventas = TarjetaKPI(kpi_frame, titulo="Ventas", valor="$0", icono="💰", color=COLORES['exito'])
        self.kpi_ventas.pack(side=tk.LEFT, padx=10)
        self.kpi_ventas.configure(width=200, height=120)
        
        self.kpi_gastos = TarjetaKPI(kpi_frame, titulo="Gastos", valor="$0", icono="💸", color=COLORES['rojo'])
        self.kpi_gastos.pack(side=tk.LEFT, padx=10)
        self.kpi_gastos.configure(width=200, height=120)
        
        self.kpi_efectivo = TarjetaKPI(kpi_frame, titulo="Efectivo", valor="$0", icono="💵", color=COLORES['azul'])
        self.kpi_efectivo.pack(side=tk.LEFT, padx=10)
        self.kpi_efectivo.configure(width=200, height=120)
        
        self.kpi_otros = TarjetaKPI(kpi_frame, titulo="Otros Medios", valor="$0", icono="💳", color=COLORES['amarillo'])
        self.kpi_otros.pack(side=tk.LEFT, padx=10)
        self.kpi_otros.configure(width=200, height=120)
        
        # Movimientos
        mov_frame = tk.Frame(main, bg=COLORES['blanco'])
        mov_frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(mov_frame, text="📋 Movimientos del Día", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['negro']).pack(anchor='w', padx=15, pady=15)
        
        cols = ('hora', 'tipo', 'concepto', 'metodo', 'valor')
        self.tree = ttk.Treeview(mov_frame, columns=cols, show='headings', height=12)
        
        for col, w in [('hora', 80), ('tipo', 100), ('concepto', 250), ('metodo', 120), ('valor', 120)]:
            self.tree.heading(col, text=col.upper())
            self.tree.column(col, width=w, anchor='e' if col == 'valor' else 'w')
        
        self.tree.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0,15))
        
        self.tree.tag_configure('ingreso', foreground=COLORES['exito'])
        self.tree.tag_configure('egreso', foreground=COLORES['rojo'])
    
    def _verificar_estado_caja(self):
        for w in self.estado_frame.winfo_children():
            w.destroy()
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT id_caja, fecha_apertura, monto_inicial, usuario_apertura FROM cajas WHERE estado='ABIERTA' ORDER BY id_caja DESC LIMIT 1")
            caja = cur.fetchone()
            conn.close()
            
            contenido = tk.Frame(self.estado_frame, bg=COLORES['blanco'])
            contenido.pack(fill=tk.X, padx=20, pady=20)
            
            if caja:
                self.caja_actual = caja[0]
                
                tk.Label(contenido, text="🟢 CAJA ABIERTA", font=FUENTES['header'],
                        bg=COLORES['blanco'], fg=COLORES['exito']).pack(side=tk.LEFT)
                tk.Label(contenido, text=f"Apertura: {caja[1]} | Monto inicial: {format_money(caja[2])} | Usuario: {caja[3]}",
                        font=FUENTES['normal'], bg=COLORES['blanco']).pack(side=tk.LEFT, padx=20)
                
                BotonModerno(contenido, texto="Cerrar Caja", icono="🔒", estilo="peligro",
                            comando=self._cerrar_caja, ancho=130, alto=40).pack(side=tk.RIGHT)
                BotonModerno(contenido, texto="Registrar Gasto", icono="💸", estilo="secundario",
                            comando=self._registrar_gasto, ancho=150, alto=40).pack(side=tk.RIGHT, padx=10)
                
                self._cargar_movimientos()
            else:
                self.caja_actual = None
                
                tk.Label(contenido, text="🔴 CAJA CERRADA", font=FUENTES['header'],
                        bg=COLORES['blanco'], fg=COLORES['rojo']).pack(side=tk.LEFT)
                
                BotonModerno(contenido, texto="Abrir Caja", icono="🔓", estilo="exito",
                            comando=self._abrir_caja, ancho=130, alto=40).pack(side=tk.RIGHT)
        except Exception as e:
            print(f"Error: {e}")
    
    def _abrir_caja(self):
        dialog = tk.Toplevel(self.parent)
        dialog.title("Abrir Caja")
        dialog.geometry("400x250")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="🔓 Abrir Caja", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['exito']).pack(pady=20)
        
        frame = tk.Frame(dialog, bg=COLORES['blanco'])
        frame.pack(pady=20)
        
        tk.Label(frame, text="Monto Inicial:", font=FUENTES['normal_bold'],
                bg=COLORES['blanco']).pack(side=tk.LEFT)
        entry = tk.Entry(frame, font=('Segoe UI', 16), width=15, justify='center')
        entry.pack(side=tk.LEFT, padx=15)
        entry.insert(0, "0")
        entry.select_range(0, tk.END)
        entry.focus()
        
        def abrir():
            try:
                monto = parse_money(entry.get())
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                cur.execute('''
                    INSERT INTO cajas (fecha_apertura, usuario_apertura, monto_inicial, estado)
                    VALUES (?, ?, ?, 'ABIERTA')
                ''', (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), self.usuario['usuario'], monto))
                conn.commit()
                conn.close()
                
                messagebox.showinfo("✅", "Caja abierta correctamente")
                dialog.destroy()
                self._verificar_estado_caja()
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        BotonModerno(dialog, texto="Abrir Caja", icono="🔓", estilo="exito",
                    comando=abrir, ancho=150, alto=45).pack(pady=15)
    
    def _cerrar_caja(self):
        if not self.caja_actual:
            return
        
        dialog = tk.Toplevel(self.parent)
        dialog.title("Cerrar Caja")
        dialog.geometry("500x400")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="🔒 Cerrar Caja - Arqueo", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['rojo']).pack(pady=20)
        
        # Calcular totales
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            cur.execute("SELECT monto_inicial FROM cajas WHERE id_caja=?", (self.caja_actual,))
            monto_inicial = cur.fetchone()[0]
            
            cur.execute("SELECT COALESCE(SUM(valor), 0) FROM movimientos_caja WHERE id_caja=? AND tipo='INGRESO'", (self.caja_actual,))
            ingresos = cur.fetchone()[0]
            
            cur.execute("SELECT COALESCE(SUM(valor), 0) FROM movimientos_caja WHERE id_caja=? AND tipo='EGRESO'", (self.caja_actual,))
            egresos = cur.fetchone()[0]
            
            conn.close()
            
            esperado = monto_inicial + ingresos - egresos
        except:
            esperado = 0
        
        # Mostrar resumen
        resumen = tk.Frame(dialog, bg=COLORES['gris_claro'])
        resumen.pack(fill=tk.X, padx=30, pady=10)
        
        for label, valor in [("Monto inicial:", monto_inicial), ("Ingresos:", ingresos),
                            ("Egresos:", egresos), ("ESPERADO:", esperado)]:
            row = tk.Frame(resumen, bg=COLORES['gris_claro'])
            row.pack(fill=tk.X, padx=15, pady=5)
            tk.Label(row, text=label, font=FUENTES['normal_bold'], bg=COLORES['gris_claro']).pack(side=tk.LEFT)
            tk.Label(row, text=format_money(valor), font=FUENTES['normal_bold'], bg=COLORES['gris_claro']).pack(side=tk.RIGHT)
        
        # Monto real
        frame = tk.Frame(dialog, bg=COLORES['blanco'])
        frame.pack(pady=20)
        
        tk.Label(frame, text="Monto Real Contado:", font=FUENTES['normal_bold'],
                bg=COLORES['blanco']).pack(side=tk.LEFT)
        entry = tk.Entry(frame, font=('Segoe UI', 16), width=15, justify='center')
        entry.pack(side=tk.LEFT, padx=15)
        entry.insert(0, str(int(esperado)))
        entry.focus()
        
        def cerrar():
            try:
                real = parse_money(entry.get())
                diferencia = real - esperado
                
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                cur.execute('''
                    UPDATE cajas SET 
                        fecha_cierre=?, usuario_cierre=?, monto_final_sistema=?,
                        monto_final_real=?, diferencia=?, estado='CERRADA'
                    WHERE id_caja=?
                ''', (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), self.usuario['usuario'],
                      esperado, real, diferencia, self.caja_actual))
                conn.commit()
                conn.close()
                
                msg = f"Caja cerrada\nEsperado: {format_money(esperado)}\nReal: {format_money(real)}\nDiferencia: {format_money(diferencia)}"
                messagebox.showinfo("✅", msg)
                dialog.destroy()
                self._verificar_estado_caja()
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        BotonModerno(dialog, texto="Cerrar Caja", icono="🔒", estilo="peligro",
                    comando=cerrar, ancho=150, alto=45).pack(pady=15)
    
    def _registrar_gasto(self):
        if not self.caja_actual:
            return
        
        dialog = tk.Toplevel(self.parent)
        dialog.title("Registrar Gasto")
        dialog.geometry("400x350")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="💸 Registrar Gasto", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['rojo']).pack(pady=20)
        
        form = tk.Frame(dialog, bg=COLORES['blanco'])
        form.pack(fill=tk.X, padx=30)
        
        tk.Label(form, text="Concepto:", font=FUENTES['normal_bold'], bg=COLORES['blanco']).pack(anchor='w')
        entry_concepto = tk.Entry(form, font=FUENTES['normal'])
        entry_concepto.pack(fill=tk.X, pady=(5,15))
        entry_concepto.focus()
        
        tk.Label(form, text="Valor:", font=FUENTES['normal_bold'], bg=COLORES['blanco']).pack(anchor='w')
        entry_valor = tk.Entry(form, font=('Segoe UI', 14))
        entry_valor.pack(fill=tk.X, pady=(5,15))
        
        def guardar():
            try:
                concepto = entry_concepto.get().strip()
                valor = parse_money(entry_valor.get())
                
                if not concepto or valor <= 0:
                    messagebox.showwarning("Error", "Complete todos los campos")
                    return
                
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                
                cur.execute('''
                    INSERT INTO movimientos_caja (id_caja, tipo, concepto, valor, metodo_pago, usuario)
                    VALUES (?, 'EGRESO', ?, ?, 'Efectivo', ?)
                ''', (self.caja_actual, concepto, valor, self.usuario['usuario']))
                
                cur.execute('''
                    INSERT INTO gastos (fecha, categoria, descripcion, valor, metodo_pago, usuario, id_caja)
                    VALUES (?, 'Otros', ?, ?, 'Efectivo', ?, ?)
                ''', (datetime.now().strftime('%Y-%m-%d'), concepto, valor, self.usuario['usuario'], self.caja_actual))
                
                conn.commit()
                conn.close()
                
                messagebox.showinfo("✅", "Gasto registrado")
                dialog.destroy()
                self._cargar_movimientos()
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        BotonModerno(dialog, texto="Guardar", icono="💾", estilo="peligro",
                    comando=guardar, ancho=120, alto=40).pack(pady=20)
    
    def _cargar_movimientos(self):
        if not self.caja_actual:
            return
        
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            cur.execute('''
                SELECT fecha, tipo, concepto, metodo_pago, valor
                FROM movimientos_caja WHERE id_caja = ?
                ORDER BY fecha DESC
            ''', (self.caja_actual,))
            
            total_ingresos = 0
            total_egresos = 0
            efectivo = 0
            otros = 0
            
            for row in cur.fetchall():
                fecha, tipo, concepto, metodo, valor = row
                hora = fecha.split(' ')[1] if ' ' in fecha else fecha
                tag = 'ingreso' if tipo == 'INGRESO' else 'egreso'
                
                if tipo == 'INGRESO':
                    total_ingresos += valor
                    if metodo == 'Efectivo':
                        efectivo += valor
                    else:
                        otros += valor
                else:
                    total_egresos += valor
                    efectivo -= valor
                
                self.tree.insert('', 'end', values=(
                    hora[:8], tipo, concepto, metodo, format_money(valor)
                ), tags=(tag,))
            
            # Actualizar KPIs
            self.kpi_ventas.actualizar_valor(format_money(total_ingresos))
            self.kpi_gastos.actualizar_valor(format_money(total_egresos))
            self.kpi_efectivo.actualizar_valor(format_money(efectivo))
            self.kpi_otros.actualizar_valor(format_money(otros))
            
            conn.close()
        except Exception as e:
            print(f"Error: {e}")
