# coding: utf-8
"""RALOZ - Módulo de Login"""
import tkinter as tk
from tkinter import messagebox
import sqlite3
import bcrypt
from utils.tema_corporativo import COLORES, FUENTES, BotonModerno

class LoginWindow:
    def __init__(self, root, db_path, on_login_success):
        self.root = root
        self.db_path = db_path
        self.on_login_success = on_login_success
        
        self.root.title("RALOZ COL SAS - Iniciar Sesión")
        self.root.geometry("450x550")
        self.root.configure(bg=COLORES['azul'])
        self.root.resizable(False, False)
        
        self._crear_interfaz()
    
    def _crear_interfaz(self):
        # Logo/Header
        header = tk.Frame(self.root, bg=COLORES['azul'])
        header.pack(fill=tk.X, pady=40)
        tk.Label(header, text="👔", font=('Segoe UI', 60), 
                bg=COLORES['azul'], fg=COLORES['blanco']).pack()
        tk.Label(header, text="RALOZ COL SAS", font=FUENTES['titulo'],
                bg=COLORES['azul'], fg=COLORES['amarillo']).pack()
        tk.Label(header, text="Sistema de Facturación v2.0", font=FUENTES['normal'],
                bg=COLORES['azul'], fg=COLORES['blanco']).pack()
        
        # Card de login
        card = tk.Frame(self.root, bg=COLORES['blanco'])
        card.pack(fill=tk.BOTH, expand=True, padx=50, pady=20)
        
        inner = tk.Frame(card, bg=COLORES['blanco'])
        inner.pack(expand=True, fill=tk.BOTH, padx=30, pady=30)
        
        tk.Label(inner, text="Iniciar Sesión", font=FUENTES['subtitulo'],
                bg=COLORES['blanco'], fg=COLORES['negro']).pack(pady=(0,25))
        
        # Usuario
        tk.Label(inner, text="Usuario", font=FUENTES['normal_bold'],
                bg=COLORES['blanco'], fg=COLORES['gris_oscuro'], anchor='w').pack(fill=tk.X)
        self.entry_usuario = tk.Entry(inner, font=('Segoe UI', 14), relief='solid', bd=1)
        self.entry_usuario.pack(fill=tk.X, pady=(5,15), ipady=8)
        self.entry_usuario.focus()
        
        # Contraseña
        tk.Label(inner, text="Contraseña", font=FUENTES['normal_bold'],
                bg=COLORES['blanco'], fg=COLORES['gris_oscuro'], anchor='w').pack(fill=tk.X)
        self.entry_password = tk.Entry(inner, font=('Segoe UI', 14), relief='solid', bd=1, show="●")
        self.entry_password.pack(fill=tk.X, pady=(5,25), ipady=8)
        self.entry_password.bind('<Return>', lambda e: self._login())
        
        # Botón login
        BotonModerno(inner, texto="Ingresar", icono="🔓", comando=self._login,
                    estilo="primario", ancho=200, alto=50).pack(pady=10)
        
        # Footer
        tk.Label(card, text="admin / 1234", font=FUENTES['pequeña'],
                bg=COLORES['blanco'], fg=COLORES['gris_medio']).pack(pady=10)
    
    def _login(self):
        usuario = self.entry_usuario.get().strip()
        password = self.entry_password.get()
        
        if not usuario or not password:
            messagebox.showwarning("Campos vacíos", "Ingrese usuario y contraseña")
            return
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT id_usuario, contraseña_hash, nombre_completo, rol FROM usuarios WHERE usuario=? AND activo=1", (usuario,))
            row = cur.fetchone()
            conn.close()
            
            if row and bcrypt.checkpw(password.encode(), row[1].encode()):
                self.on_login_success({
                    'id': row[0],
                    'usuario': usuario,
                    'nombre': row[2],
                    'rol': row[3]
                })
            else:
                messagebox.showerror("Error", "Usuario o contraseña incorrectos")
                self.entry_password.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Error", f"Error de conexión: {e}")
