# coding: utf-8
"""RALOZ - Módulo de Facturación"""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
from utils.tema_corporativo import COLORES, FUENTES, BotonModerno, HeaderModerno
from utils.money_parser import format_money
from utils.impresora import generar_ticket_texto

class FacturacionModule:
    def __init__(self, parent, usuario, db_path):
        self.parent = parent
        self.usuario = usuario
        self.db_path = db_path
        self._crear_interfaz()
    
    def _crear_interfaz(self):
        HeaderModerno(self.parent, titulo="FACTURACIÓN", icono="🧾", color=COLORES['azul']).pack(fill=tk.X)
        
        main = tk.Frame(self.parent, bg=COLORES['fondo_principal'])
        main.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Toolbar
        toolbar = tk.Frame(main, bg=COLORES['blanco'])
        toolbar.pack(fill=tk.X, pady=(0,15))
        
        tk.Label(toolbar, text="🔍", font=('Segoe UI', 14), bg=COLORES['blanco']).pack(side=tk.LEFT, padx=(15,5))
        self.entry_buscar = tk.Entry(toolbar, font=FUENTES['normal'], width=25)
        self.entry_buscar.pack(side=tk.LEFT, padx=5, pady=15, ipady=5)
        self.entry_buscar.bind('<KeyRelease>', lambda e: self._cargar_facturas())
        
        tk.Label(toolbar, text="Estado:", font=FUENTES['normal'], bg=COLORES['blanco']).pack(side=tk.LEFT, padx=(15,5))
        self.combo_estado = ttk.Combobox(toolbar, values=['Todas', 'ACTIVA', 'ANULADA'], state='readonly', width=12)
        self.combo_estado.current(0)
        self.combo_estado.pack(side=tk.LEFT)
        self.combo_estado.bind('<<ComboboxSelected>>', lambda e: self._cargar_facturas())
        
        BotonModerno(toolbar, texto="Ver Detalle", icono="👁️", estilo="primario",
                    comando=self._ver_detalle, ancho=130, alto=40).pack(side=tk.LEFT, padx=10)
        BotonModerno(toolbar, texto="Imprimir", icono="🖨️", estilo="secundario",
                    comando=self._imprimir, ancho=120, alto=40).pack(side=tk.LEFT, padx=5)
        BotonModerno(toolbar, texto="Anular", icono="❌", estilo="peligro",
                    comando=self._anular, ancho=100, alto=40).pack(side=tk.LEFT, padx=5)
        
        # Tabla
        tabla = tk.Frame(main, bg=COLORES['blanco'])
        tabla.pack(fill=tk.BOTH, expand=True)
        
        cols = ('id', 'numero', 'fecha', 'cliente', 'subtotal', 'iva', 'total', 'metodo', 'estado')
        self.tree = ttk.Treeview(tabla, columns=cols, show='headings', height=18)
        
        for col, w in [('id', 50), ('numero', 100), ('fecha', 100), ('cliente', 180),
                       ('subtotal', 100), ('iva', 80), ('total', 110), ('metodo', 100), ('estado', 80)]:
            self.tree.heading(col, text=col.upper())
            self.tree.column(col, width=w, anchor='e' if col in ['subtotal', 'iva', 'total'] else 'w')
        
        scroll = ttk.Scrollbar(tabla, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=15, pady=15)
        scroll.pack(side=tk.RIGHT, fill=tk.Y, pady=15)
        
        self.tree.tag_configure('anulada', foreground=COLORES['gris_medio'])
        self.tree.bind('<Double-1>', lambda e: self._ver_detalle())
        
        self._cargar_facturas()
    
    def _cargar_facturas(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        buscar = self.entry_buscar.get().strip()
        estado = self.combo_estado.get()
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            query = """
                SELECT f.id_factura, f.numero_factura, f.fecha, c.nombre, 
                       f.subtotal, f.iva, f.total, f.metodo_pago, f.estado
                FROM facturas f
                LEFT JOIN clientes c ON f.id_cliente = c.id_cliente
                WHERE 1=1
            """
            params = []
            
            if buscar:
                query += " AND (f.numero_factura LIKE ? OR c.nombre LIKE ?)"
                params.extend([f'%{buscar}%', f'%{buscar}%'])
            
            if estado != 'Todas':
                query += " AND f.estado = ?"
                params.append(estado)
            
            query += " ORDER BY f.fecha DESC, f.id_factura DESC LIMIT 100"
            
            cur.execute(query, params)
            
            for row in cur.fetchall():
                tag = 'anulada' if row[8] == 'ANULADA' else ''
                self.tree.insert('', 'end', values=(
                    row[0], row[1], row[2], row[3] or 'N/A',
                    format_money(row[4]), format_money(row[5]), format_money(row[6]),
                    row[7], row[8]
                ), tags=(tag,))
            
            conn.close()
        except Exception as e:
            print(f"Error: {e}")
    
    def _ver_detalle(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Seleccione", "Seleccione una factura")
            return
        
        item = self.tree.item(sel[0])['values']
        id_factura = item[0]
        
        dialog = tk.Toplevel(self.parent)
        dialog.title(f"Factura {item[1]}")
        dialog.geometry("600x500")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        
        # Header
        header = tk.Frame(dialog, bg=COLORES['azul'])
        header.pack(fill=tk.X)
        tk.Label(header, text=f"🧾 Factura {item[1]}", font=FUENTES['header'],
                bg=COLORES['azul'], fg=COLORES['blanco']).pack(pady=15)
        
        # Info
        info = tk.Frame(dialog, bg=COLORES['gris_claro'])
        info.pack(fill=tk.X, padx=20, pady=15)
        
        for label, valor in [("Fecha:", item[2]), ("Cliente:", item[3]),
                            ("Método:", item[7]), ("Estado:", item[8])]:
            row = tk.Frame(info, bg=COLORES['gris_claro'])
            row.pack(fill=tk.X, padx=15, pady=3)
            tk.Label(row, text=label, font=FUENTES['normal_bold'], bg=COLORES['gris_claro'], width=10, anchor='w').pack(side=tk.LEFT)
            tk.Label(row, text=valor, font=FUENTES['normal'], bg=COLORES['gris_claro']).pack(side=tk.LEFT)
        
        # Detalle
        tk.Label(dialog, text="Detalle:", font=FUENTES['normal_bold'], bg=COLORES['blanco']).pack(anchor='w', padx=20, pady=(10,5))
        
        cols = ('producto', 'cantidad', 'precio', 'total')
        tree = ttk.Treeview(dialog, columns=cols, show='headings', height=8)
        
        for col, w in [('producto', 250), ('cantidad', 80), ('precio', 100), ('total', 100)]:
            tree.heading(col, text=col.upper())
            tree.column(col, width=w, anchor='e' if col != 'producto' else 'w')
        
        tree.pack(fill=tk.X, padx=20, pady=5)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("""
                SELECT p.nombre, d.cantidad, d.precio_unitario, d.total_linea
                FROM factura_detalle d
                JOIN productos p ON d.id_producto = p.id_producto
                WHERE d.id_factura = ?
            """, (id_factura,))
            
            for row in cur.fetchall():
                tree.insert('', 'end', values=(row[0], row[1], format_money(row[2]), format_money(row[3])))
            
            conn.close()
        except:
            pass
        
        # Totales
        totales = tk.Frame(dialog, bg=COLORES['blanco'])
        totales.pack(fill=tk.X, padx=20, pady=15)
        
        for label, valor in [("Subtotal:", item[4]), ("IVA:", item[5]), ("TOTAL:", item[6])]:
            row = tk.Frame(totales, bg=COLORES['blanco'])
            row.pack(fill=tk.X)
            tk.Label(row, text=label, font=FUENTES['normal_bold'], bg=COLORES['blanco'], width=15, anchor='e').pack(side=tk.LEFT, expand=True)
            tk.Label(row, text=valor, font=FUENTES['normal_bold'], bg=COLORES['blanco'], 
                    fg=COLORES['exito'] if label == "TOTAL:" else COLORES['negro']).pack(side=tk.LEFT)
    
    def _imprimir(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Seleccione", "Seleccione una factura")
            return
        
        item = self.tree.item(sel[0])['values']
        id_factura = item[0]
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            # Obtener config empresa
            cur.execute("SELECT valor FROM configuracion WHERE clave IN ('empresa_nombre', 'empresa_nit', 'empresa_direccion', 'empresa_telefono')")
            config = {r[0]: r[0] for r in cur.fetchall()}
            empresa = {
                'nombre': 'RALOZ COL SAS',
                'nit': '900.XXX.XXX-X',
                'direccion': 'Dirección',
                'telefono': 'Teléfono'
            }
            
            # Obtener factura
            cur.execute("""
                SELECT f.numero_factura, f.fecha, f.hora, c.nombre, f.subtotal, f.iva, f.total, f.metodo_pago
                FROM facturas f LEFT JOIN clientes c ON f.id_cliente = c.id_cliente
                WHERE f.id_factura = ?
            """, (id_factura,))
            fac = cur.fetchone()
            
            factura = {
                'numero': fac[0], 'fecha': fac[1], 'hora': fac[2] or '',
                'cliente': fac[3] or 'CONSUMIDOR FINAL',
                'subtotal': fac[4], 'iva': fac[5], 'total': fac[6], 'metodo_pago': fac[7]
            }
            
            # Obtener items
            cur.execute("""
                SELECT p.nombre, d.cantidad, d.total_linea
                FROM factura_detalle d JOIN productos p ON d.id_producto = p.id_producto
                WHERE d.id_factura = ?
            """, (id_factura,))
            items = [{'nombre': r[0], 'cantidad': r[1], 'total': r[2]} for r in cur.fetchall()]
            
            conn.close()
            
            # Generar ticket
            ticket = generar_ticket_texto(factura, empresa, items)
            
            # Mostrar preview
            preview = tk.Toplevel(self.parent)
            preview.title("Vista Previa - Ticket")
            preview.geometry("450x600")
            preview.configure(bg=COLORES['blanco'])
            
            text = tk.Text(preview, font=('Courier New', 10), wrap=tk.WORD)
            text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            text.insert('1.0', ticket)
            text.config(state='disabled')
            
            def copiar():
                preview.clipboard_clear()
                preview.clipboard_append(ticket)
                messagebox.showinfo("✅", "Copiado al portapapeles")
            
            BotonModerno(preview, texto="Copiar", icono="📋", estilo="primario",
                        comando=copiar, ancho=100, alto=35).pack(pady=10)
            
        except Exception as e:
            messagebox.showerror("Error", str(e))
    
    def _anular(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Seleccione", "Seleccione una factura")
            return
        
        item = self.tree.item(sel[0])['values']
        
        if item[8] == 'ANULADA':
            messagebox.showinfo("Info", "Esta factura ya está anulada")
            return
        
        if not messagebox.askyesno("Confirmar", f"¿Anular factura {item[1]}?\n\nEsta acción no se puede deshacer."):
            return
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("UPDATE facturas SET estado='ANULADA' WHERE id_factura=?", (item[0],))
            conn.commit()
            conn.close()
            
            messagebox.showinfo("✅", "Factura anulada")
            self._cargar_facturas()
        except Exception as e:
            messagebox.showerror("Error", str(e))
