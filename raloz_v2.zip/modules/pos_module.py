# coding: utf-8
"""RALOZ - Punto de Venta (POS) con Escáner"""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
from utils.tema_corporativo import COLORES, FUENTES, BotonModerno, HeaderModerno
from utils.money_parser import format_money, parse_money
from models.series import obtener_siguiente_numero

class POSModule:
    def __init__(self, parent, usuario, db_path):
        self.parent = parent
        self.usuario = usuario
        self.db_path = db_path
        
        self.carrito = []  # Lista de items {producto, cantidad, precio, total}
        self.cliente_actual = {'id': 1, 'nombre': 'CONSUMIDOR FINAL'}
        
        self._crear_interfaz()
        self._cargar_productos()
    
    def _crear_interfaz(self):
        # Header
        HeaderModerno(self.parent, titulo="PUNTO DE VENTA", icono="🛒", 
                     color=COLORES['exito']).pack(fill=tk.X)
        
        # Main container
        main = tk.Frame(self.parent, bg=COLORES['fondo_principal'])
        main.pack(fill=tk.BOTH, expand=True)
        
        # Panel izquierdo - Productos
        left = tk.Frame(main, bg=COLORES['blanco'], width=700)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(15,5), pady=15)
        
        # Barra de búsqueda y escáner
        search_frame = tk.Frame(left, bg=COLORES['blanco'])
        search_frame.pack(fill=tk.X, padx=15, pady=15)
        
        tk.Label(search_frame, text="🔍 Código / Nombre:", font=FUENTES['normal_bold'],
                bg=COLORES['blanco']).pack(side=tk.LEFT)
        
        self.entry_buscar = tk.Entry(search_frame, font=('Segoe UI', 14), width=30)
        self.entry_buscar.pack(side=tk.LEFT, padx=10, ipady=5)
        self.entry_buscar.bind('<Return>', self._buscar_producto)
        self.entry_buscar.bind('<KeyRelease>', self._filtrar_productos)
        self.entry_buscar.focus()
        
        BotonModerno(search_frame, texto="Buscar", icono="🔍", estilo="primario",
                    comando=lambda: self._buscar_producto(None), ancho=100, alto=40).pack(side=tk.LEFT, padx=5)
        
        # Categorías rápidas
        cat_frame = tk.Frame(left, bg=COLORES['blanco'])
        cat_frame.pack(fill=tk.X, padx=15)
        
        tk.Label(cat_frame, text="Categorías:", font=FUENTES['normal_bold'],
                bg=COLORES['blanco']).pack(side=tk.LEFT)
        
        self.combo_categoria = ttk.Combobox(cat_frame, state='readonly', width=20, font=FUENTES['normal'])
        self.combo_categoria.pack(side=tk.LEFT, padx=10)
        self.combo_categoria.bind('<<ComboboxSelected>>', self._filtrar_por_categoria)
        self._cargar_categorias()
        
        # Grid de productos
        tk.Frame(left, bg=COLORES['gris'], height=2).pack(fill=tk.X, padx=15, pady=10)
        
        # Canvas con scroll para productos
        prod_container = tk.Frame(left, bg=COLORES['blanco'])
        prod_container.pack(fill=tk.BOTH, expand=True, padx=15, pady=5)
        
        self.canvas_productos = tk.Canvas(prod_container, bg=COLORES['blanco'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(prod_container, orient="vertical", command=self.canvas_productos.yview)
        self.frame_productos = tk.Frame(self.canvas_productos, bg=COLORES['blanco'])
        
        self.frame_productos.bind("<Configure>", 
            lambda e: self.canvas_productos.configure(scrollregion=self.canvas_productos.bbox("all")))
        self.canvas_productos.create_window((0, 0), window=self.frame_productos, anchor="nw")
        self.canvas_productos.configure(yscrollcommand=scrollbar.set)
        
        self.canvas_productos.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Panel derecho - Carrito
        right = tk.Frame(main, bg=COLORES['blanco'], width=450)
        right.pack(side=tk.RIGHT, fill=tk.Y, padx=(5,15), pady=15)
        right.pack_propagate(False)
        
        # Cliente
        cliente_frame = tk.Frame(right, bg=COLORES['azul_claro'])
        cliente_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(cliente_frame, text="👤 Cliente:", font=FUENTES['normal_bold'],
                bg=COLORES['azul_claro']).pack(side=tk.LEFT, padx=10, pady=10)
        self.lbl_cliente = tk.Label(cliente_frame, text=self.cliente_actual['nombre'],
                                   font=FUENTES['normal'], bg=COLORES['azul_claro'])
        self.lbl_cliente.pack(side=tk.LEFT)
        BotonModerno(cliente_frame, texto="Cambiar", estilo="outline", ancho=80, alto=30,
                    comando=self._seleccionar_cliente).pack(side=tk.RIGHT, padx=10, pady=5)
        
        # Título carrito
        tk.Label(right, text="🛒 CARRITO", font=FUENTES['header'],
                bg=COLORES['blanco'], fg=COLORES['negro']).pack(pady=10)
        
        # Lista carrito
        cart_frame = tk.Frame(right, bg=COLORES['blanco'])
        cart_frame.pack(fill=tk.BOTH, expand=True, padx=10)
        
        cols = ('producto', 'cant', 'precio', 'total')
        self.tree_carrito = ttk.Treeview(cart_frame, columns=cols, show='headings', height=12)
        
        self.tree_carrito.heading('producto', text='Producto')
        self.tree_carrito.heading('cant', text='Cant')
        self.tree_carrito.heading('precio', text='Precio')
        self.tree_carrito.heading('total', text='Total')
        
        self.tree_carrito.column('producto', width=180)
        self.tree_carrito.column('cant', width=50, anchor='center')
        self.tree_carrito.column('precio', width=80, anchor='e')
        self.tree_carrito.column('total', width=90, anchor='e')
        
        self.tree_carrito.pack(fill=tk.BOTH, expand=True)
        self.tree_carrito.bind('<Double-1>', self._editar_item)
        self.tree_carrito.bind('<Delete>', self._eliminar_item)
        
        # Botón eliminar
        BotonModerno(right, texto="Eliminar Seleccionado", icono="🗑️", estilo="peligro",
                    comando=lambda: self._eliminar_item(None), ancho=200, alto=35).pack(pady=5)
        
        # Totales
        totales_frame = tk.Frame(right, bg=COLORES['gris_claro'])
        totales_frame.pack(fill=tk.X, padx=10, pady=10)
        
        row = tk.Frame(totales_frame, bg=COLORES['gris_claro'])
        row.pack(fill=tk.X, padx=15, pady=5)
        tk.Label(row, text="Subtotal:", font=FUENTES['normal'], bg=COLORES['gris_claro']).pack(side=tk.LEFT)
        self.lbl_subtotal = tk.Label(row, text="$0", font=FUENTES['normal_bold'], bg=COLORES['gris_claro'])
        self.lbl_subtotal.pack(side=tk.RIGHT)
        
        row = tk.Frame(totales_frame, bg=COLORES['gris_claro'])
        row.pack(fill=tk.X, padx=15, pady=5)
        tk.Label(row, text="IVA (19%):", font=FUENTES['normal'], bg=COLORES['gris_claro']).pack(side=tk.LEFT)
        self.lbl_iva = tk.Label(row, text="$0", font=FUENTES['normal_bold'], bg=COLORES['gris_claro'])
        self.lbl_iva.pack(side=tk.RIGHT)
        
        row = tk.Frame(totales_frame, bg=COLORES['gris_claro'])
        row.pack(fill=tk.X, padx=15, pady=10)
        tk.Label(row, text="TOTAL:", font=FUENTES['precio'], bg=COLORES['gris_claro']).pack(side=tk.LEFT)
        self.lbl_total = tk.Label(row, text="$0", font=FUENTES['precio'], 
                                  bg=COLORES['gris_claro'], fg=COLORES['exito'])
        self.lbl_total.pack(side=tk.RIGHT)
        
        # Método de pago
        pago_frame = tk.Frame(right, bg=COLORES['blanco'])
        pago_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(pago_frame, text="Método de Pago:", font=FUENTES['normal_bold'],
                bg=COLORES['blanco']).pack(side=tk.LEFT)
        self.combo_pago = ttk.Combobox(pago_frame, state='readonly', width=15, font=FUENTES['normal'])
        self.combo_pago['values'] = ['Efectivo', 'Tarjeta Débito', 'Tarjeta Crédito', 'Nequi', 'Daviplata', 'Transferencia']
        self.combo_pago.current(0)
        self.combo_pago.pack(side=tk.RIGHT)
        
        # Botones finales
        btns_frame = tk.Frame(right, bg=COLORES['blanco'])
        btns_frame.pack(fill=tk.X, padx=10, pady=15)
        
        BotonModerno(btns_frame, texto="Limpiar", icono="🗑️", estilo="peligro",
                    comando=self._limpiar_carrito, ancho=130, alto=50).pack(side=tk.LEFT, padx=5)
        BotonModerno(btns_frame, texto="FACTURAR", icono="✅", estilo="exito",
                    comando=self._facturar, ancho=200, alto=50).pack(side=tk.RIGHT, padx=5)
    
    def _cargar_categorias(self):
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT nombre FROM categorias WHERE activo=1 ORDER BY nombre")
            cats = ['Todas'] + [r[0] for r in cur.fetchall()]
            conn.close()
            self.combo_categoria['values'] = cats
            self.combo_categoria.current(0)
        except:
            self.combo_categoria['values'] = ['Todas']
    
    def _cargar_productos(self, filtro_categoria=None, filtro_texto=None):
        # Limpiar grid
        for w in self.frame_productos.winfo_children():
            w.destroy()
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            query = '''
                SELECT p.id_producto, p.codigo, p.nombre, p.precio_venta,
                       COALESCE(SUM(i.stock_actual), 0) as stock,
                       c.color
                FROM productos p
                LEFT JOIN inventario i ON p.id_producto = i.id_producto
                LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
                WHERE p.activo = 1
            '''
            params = []
            
            if filtro_categoria and filtro_categoria != 'Todas':
                query += " AND c.nombre = ?"
                params.append(filtro_categoria)
            
            if filtro_texto:
                query += " AND (p.nombre LIKE ? OR p.codigo LIKE ? OR p.codigo_barras LIKE ?)"
                params.extend([f'%{filtro_texto}%', f'%{filtro_texto}%', f'%{filtro_texto}%'])
            
            query += " GROUP BY p.id_producto ORDER BY p.nombre LIMIT 50"
            
            cur.execute(query, params)
            productos = cur.fetchall()
            conn.close()
            
            # Crear grid de productos
            col = 0
            row = 0
            for prod in productos:
                self._crear_tarjeta_producto(row, col, prod)
                col += 1
                if col >= 4:
                    col = 0
                    row += 1
        except Exception as e:
            print(f"Error cargando productos: {e}")
    
    def _crear_tarjeta_producto(self, row, col, prod):
        id_prod, codigo, nombre, precio, stock, color = prod
        
        card = tk.Frame(self.frame_productos, bg=COLORES['blanco'], 
                       highlightthickness=1, highlightbackground=COLORES['gris'],
                       cursor='hand2')
        card.grid(row=row, column=col, padx=8, pady=8, sticky='nsew')
        
        # Icono/Imagen placeholder
        img_frame = tk.Frame(card, bg=color or COLORES['gris_claro'], width=100, height=80)
        img_frame.pack(padx=10, pady=10)
        img_frame.pack_propagate(False)
        tk.Label(img_frame, text="👔", font=('Segoe UI', 32), bg=color or COLORES['gris_claro']).pack(expand=True)
        
        # Nombre
        tk.Label(card, text=nombre[:18], font=FUENTES['normal_bold'],
                bg=COLORES['blanco']).pack()
        
        # Precio
        tk.Label(card, text=format_money(precio), font=FUENTES['grande'],
                bg=COLORES['blanco'], fg=COLORES['azul']).pack()
        
        # Stock
        color_stock = COLORES['exito'] if stock > 5 else COLORES['rojo'] if stock > 0 else COLORES['gris_oscuro']
        tk.Label(card, text=f"Stock: {int(stock)}", font=FUENTES['pequeña'],
                bg=COLORES['blanco'], fg=color_stock).pack(pady=(0,10))
        
        # Eventos
        def on_enter(e):
            card.configure(highlightbackground=COLORES['azul'], highlightthickness=2)
        def on_leave(e):
            card.configure(highlightbackground=COLORES['gris'], highlightthickness=1)
        def on_click(e):
            self._agregar_al_carrito(id_prod, nombre, precio, stock)
        
        card.bind('<Enter>', on_enter)
        card.bind('<Leave>', on_leave)
        card.bind('<Button-1>', on_click)
        for child in card.winfo_children():
            child.bind('<Button-1>', on_click)
    
    def _buscar_producto(self, event):
        texto = self.entry_buscar.get().strip()
        if texto:
            # Buscar por código de barras exacto primero
            try:
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                cur.execute('''
                    SELECT p.id_producto, p.nombre, p.precio_venta, COALESCE(SUM(i.stock_actual), 0)
                    FROM productos p
                    LEFT JOIN inventario i ON p.id_producto = i.id_producto
                    WHERE (p.codigo_barras = ? OR p.codigo = ?) AND p.activo = 1
                    GROUP BY p.id_producto
                ''', (texto, texto))
                row = cur.fetchone()
                conn.close()
                
                if row:
                    # Encontrado por código exacto - agregar directo
                    self._agregar_al_carrito(row[0], row[1], row[2], row[3])
                    self.entry_buscar.delete(0, tk.END)
                    return
            except:
                pass
        
        # Si no es código exacto, filtrar
        self._cargar_productos(filtro_texto=texto)
    
    def _filtrar_productos(self, event):
        texto = self.entry_buscar.get().strip()
        if len(texto) >= 2 or len(texto) == 0:
            cat = self.combo_categoria.get()
            self._cargar_productos(filtro_categoria=cat if cat != 'Todas' else None, filtro_texto=texto if texto else None)
    
    def _filtrar_por_categoria(self, event):
        cat = self.combo_categoria.get()
        texto = self.entry_buscar.get().strip()
        self._cargar_productos(filtro_categoria=cat if cat != 'Todas' else None, filtro_texto=texto if texto else None)
    
    def _agregar_al_carrito(self, id_producto, nombre, precio, stock):
        if stock <= 0:
            messagebox.showwarning("Sin Stock", f"{nombre} no tiene stock disponible")
            return
        
        # Verificar si ya está en el carrito
        for item in self.carrito:
            if item['id'] == id_producto:
                if item['cantidad'] < stock:
                    item['cantidad'] += 1
                    item['total'] = item['cantidad'] * item['precio']
                    self._actualizar_carrito()
                else:
                    messagebox.showwarning("Stock", f"No hay más stock de {nombre}")
                return
        
        # Agregar nuevo
        self.carrito.append({
            'id': id_producto,
            'nombre': nombre,
            'precio': precio,
            'cantidad': 1,
            'total': precio
        })
        self._actualizar_carrito()
    
    def _actualizar_carrito(self):
        # Limpiar treeview
        for item in self.tree_carrito.get_children():
            self.tree_carrito.delete(item)
        
        subtotal = 0
        for item in self.carrito:
            self.tree_carrito.insert('', 'end', values=(
                item['nombre'][:25],
                item['cantidad'],
                format_money(item['precio']),
                format_money(item['total'])
            ))
            subtotal += item['total']
        
        iva = subtotal * 0.19
        total = subtotal + iva
        
        self.lbl_subtotal.config(text=format_money(subtotal))
        self.lbl_iva.config(text=format_money(iva))
        self.lbl_total.config(text=format_money(total))
    
    def _editar_item(self, event):
        sel = self.tree_carrito.selection()
        if not sel:
            return
        
        idx = self.tree_carrito.index(sel[0])
        item = self.carrito[idx]
        
        # Dialog para cantidad
        dialog = tk.Toplevel(self.parent)
        dialog.title("Editar Cantidad")
        dialog.geometry("300x150")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text=f"Producto: {item['nombre']}", font=FUENTES['normal_bold'],
                bg=COLORES['blanco']).pack(pady=15)
        
        frame = tk.Frame(dialog, bg=COLORES['blanco'])
        frame.pack()
        tk.Label(frame, text="Cantidad:", font=FUENTES['normal'], bg=COLORES['blanco']).pack(side=tk.LEFT)
        entry = tk.Entry(frame, font=FUENTES['normal'], width=10, justify='center')
        entry.pack(side=tk.LEFT, padx=10)
        entry.insert(0, str(item['cantidad']))
        entry.select_range(0, tk.END)
        entry.focus()
        
        def guardar():
            try:
                nueva_cant = int(entry.get())
                if nueva_cant <= 0:
                    del self.carrito[idx]
                else:
                    self.carrito[idx]['cantidad'] = nueva_cant
                    self.carrito[idx]['total'] = nueva_cant * self.carrito[idx]['precio']
                self._actualizar_carrito()
                dialog.destroy()
            except:
                pass
        
        entry.bind('<Return>', lambda e: guardar())
        BotonModerno(dialog, texto="Guardar", estilo="exito", comando=guardar,
                    ancho=100, alto=35).pack(pady=15)
    
    def _eliminar_item(self, event):
        sel = self.tree_carrito.selection()
        if sel:
            idx = self.tree_carrito.index(sel[0])
            del self.carrito[idx]
            self._actualizar_carrito()
    
    def _limpiar_carrito(self):
        self.carrito = []
        self._actualizar_carrito()
    
    def _seleccionar_cliente(self):
        # Dialog para seleccionar cliente
        dialog = tk.Toplevel(self.parent)
        dialog.title("Seleccionar Cliente")
        dialog.geometry("500x400")
        dialog.configure(bg=COLORES['blanco'])
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="🔍 Buscar Cliente", font=FUENTES['header'],
                bg=COLORES['blanco']).pack(pady=15)
        
        entry = tk.Entry(dialog, font=FUENTES['normal'], width=40)
        entry.pack(pady=10)
        entry.focus()
        
        tree = ttk.Treeview(dialog, columns=('id', 'doc', 'nombre'), show='headings', height=10)
        tree.heading('id', text='ID')
        tree.heading('doc', text='Documento')
        tree.heading('nombre', text='Nombre')
        tree.column('id', width=50)
        tree.column('doc', width=120)
        tree.column('nombre', width=250)
        tree.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        def buscar(e=None):
            texto = entry.get().strip()
            for item in tree.get_children():
                tree.delete(item)
            try:
                conn = sqlite3.connect(self.db_path)
                cur = conn.cursor()
                cur.execute('''SELECT id_cliente, numero_documento, nombre FROM clientes 
                              WHERE activo=1 AND (nombre LIKE ? OR numero_documento LIKE ?)
                              ORDER BY nombre LIMIT 20''', (f'%{texto}%', f'%{texto}%'))
                for row in cur.fetchall():
                    tree.insert('', 'end', values=row)
                conn.close()
            except:
                pass
        
        entry.bind('<KeyRelease>', buscar)
        buscar()
        
        def seleccionar(e=None):
            sel = tree.selection()
            if sel:
                item = tree.item(sel[0])['values']
                self.cliente_actual = {'id': item[0], 'nombre': item[2]}
                self.lbl_cliente.config(text=item[2][:25])
                dialog.destroy()
        
        tree.bind('<Double-1>', seleccionar)
    
    def _facturar(self):
        if not self.carrito:
            messagebox.showwarning("Carrito Vacío", "Agregue productos al carrito")
            return
        
        # Verificar caja abierta
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT id_caja FROM cajas WHERE estado='ABIERTA' ORDER BY id_caja DESC LIMIT 1")
            caja = cur.fetchone()
            
            if not caja:
                conn.close()
                messagebox.showwarning("Caja Cerrada", "Debe abrir caja antes de facturar")
                return
            
            id_caja = caja[0]
            
            # Calcular totales
            subtotal = sum(item['total'] for item in self.carrito)
            iva = subtotal * 0.19
            total = subtotal + iva
            
            # Obtener número de factura
            numero = obtener_siguiente_numero(self.db_path, 'FACTURA')
            fecha = datetime.now().strftime('%Y-%m-%d')
            hora = datetime.now().strftime('%H:%M:%S')
            metodo = self.combo_pago.get()
            
            # Insertar factura
            cur.execute('''
                INSERT INTO facturas (numero_factura, fecha, hora, id_cliente, subtotal, iva, total, metodo_pago, usuario, id_caja)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (numero, fecha, hora, self.cliente_actual['id'], subtotal, iva, total, metodo, self.usuario['usuario'], id_caja))
            
            id_factura = cur.lastrowid
            
            # Insertar detalle
            for item in self.carrito:
                cur.execute('''
                    INSERT INTO factura_detalle (id_factura, id_producto, cantidad, precio_unitario, total_linea)
                    VALUES (?, ?, ?, ?, ?)
                ''', (id_factura, item['id'], item['cantidad'], item['precio'], item['total']))
                
                # Descontar inventario
                cur.execute('''
                    UPDATE inventario SET stock_actual = stock_actual - ?
                    WHERE id_producto = ? AND stock_actual >= ?
                ''', (item['cantidad'], item['id'], item['cantidad']))
            
            # Registrar movimiento de caja
            cur.execute('''
                INSERT INTO movimientos_caja (id_caja, tipo, concepto, valor, metodo_pago, referencia, usuario)
                VALUES (?, 'INGRESO', 'Venta', ?, ?, ?, ?)
            ''', (id_caja, total, metodo, numero, self.usuario['usuario']))
            
            conn.commit()
            conn.close()
            
            messagebox.showinfo("✅ Factura Creada", f"Factura {numero}\nTotal: {format_money(total)}")
            
            # Limpiar
            self._limpiar_carrito()
            self.entry_buscar.focus()
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al facturar: {e}")
