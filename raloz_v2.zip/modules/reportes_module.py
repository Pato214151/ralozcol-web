# coding: utf-8
"""RALOZ - Módulo de Reportes con Gráficas"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sqlite3
from datetime import datetime, timedelta
from utils.tema_corporativo import COLORES, FUENTES, BotonModerno, HeaderModerno
from utils.money_parser import format_money

try:
    import matplotlib
    matplotlib.use('TkAgg')
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.figure import Figure
    MATPLOTLIB_DISPONIBLE = True
except ImportError:
    MATPLOTLIB_DISPONIBLE = False

class ReportesModule:
    def __init__(self, parent, usuario, db_path):
        self.parent = parent
        self.usuario = usuario
        self.db_path = db_path
        self._crear_interfaz()
    
    def _crear_interfaz(self):
        HeaderModerno(self.parent, titulo="REPORTES", icono="📈", color=COLORES['azul_oscuro']).pack(fill=tk.X)
        
        main = tk.Frame(self.parent, bg=COLORES['fondo_principal'])
        main.pack(fill=tk.BOTH, expand=True)
        
        # Panel de filtros
        filtros = tk.Frame(main, bg=COLORES['blanco'])
        filtros.pack(fill=tk.X, padx=20, pady=15)
        
        tk.Label(filtros, text="📅 Período:", font=FUENTES['normal_bold'],
                bg=COLORES['blanco']).pack(side=tk.LEFT, padx=(15,10))
        
        self.combo_periodo = ttk.Combobox(filtros, state='readonly', width=15,
                                          values=['Hoy', 'Esta Semana', 'Este Mes', 'Este Año', 'Personalizado'])
        self.combo_periodo.current(2)
        self.combo_periodo.pack(side=tk.LEFT, padx=5)
        self.combo_periodo.bind('<<ComboboxSelected>>', lambda e: self._actualizar_reporte())
        
        tk.Label(filtros, text="Desde:", font=FUENTES['normal'], bg=COLORES['blanco']).pack(side=tk.LEFT, padx=(20,5))
        self.entry_desde = tk.Entry(filtros, font=FUENTES['normal'], width=12)
        self.entry_desde.pack(side=tk.LEFT)
        self.entry_desde.insert(0, datetime.now().replace(day=1).strftime('%Y-%m-%d'))
        
        tk.Label(filtros, text="Hasta:", font=FUENTES['normal'], bg=COLORES['blanco']).pack(side=tk.LEFT, padx=(10,5))
        self.entry_hasta = tk.Entry(filtros, font=FUENTES['normal'], width=12)
        self.entry_hasta.pack(side=tk.LEFT)
        self.entry_hasta.insert(0, datetime.now().strftime('%Y-%m-%d'))
        
        BotonModerno(filtros, texto="Generar", icono="🔄", estilo="primario",
                    comando=self._actualizar_reporte, ancho=110, alto=38).pack(side=tk.LEFT, padx=15)
        BotonModerno(filtros, texto="Exportar", icono="📥", estilo="exito",
                    comando=self._exportar, ancho=110, alto=38).pack(side=tk.LEFT, padx=5)
        
        # Notebook para diferentes reportes
        self.notebook = ttk.Notebook(main)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0,20))
        
        # Tab Resumen
        self.tab_resumen = tk.Frame(self.notebook, bg=COLORES['blanco'])
        self.notebook.add(self.tab_resumen, text="📊 Resumen")
        
        # Tab Ventas
        self.tab_ventas = tk.Frame(self.notebook, bg=COLORES['blanco'])
        self.notebook.add(self.tab_ventas, text="💰 Ventas")
        
        # Tab Productos
        self.tab_productos = tk.Frame(self.notebook, bg=COLORES['blanco'])
        self.notebook.add(self.tab_productos, text="📦 Productos")
        
        # Tab Clientes
        self.tab_clientes = tk.Frame(self.notebook, bg=COLORES['blanco'])
        self.notebook.add(self.tab_clientes, text="👥 Clientes")
        
        self._actualizar_reporte()
    
    def _obtener_fechas(self):
        periodo = self.combo_periodo.get()
        hoy = datetime.now()
        
        if periodo == 'Hoy':
            desde = hasta = hoy.strftime('%Y-%m-%d')
        elif periodo == 'Esta Semana':
            desde = (hoy - timedelta(days=hoy.weekday())).strftime('%Y-%m-%d')
            hasta = hoy.strftime('%Y-%m-%d')
        elif periodo == 'Este Mes':
            desde = hoy.replace(day=1).strftime('%Y-%m-%d')
            hasta = hoy.strftime('%Y-%m-%d')
        elif periodo == 'Este Año':
            desde = hoy.replace(month=1, day=1).strftime('%Y-%m-%d')
            hasta = hoy.strftime('%Y-%m-%d')
        else:
            desde = self.entry_desde.get()
            hasta = self.entry_hasta.get()
        
        self.entry_desde.delete(0, tk.END)
        self.entry_desde.insert(0, desde)
        self.entry_hasta.delete(0, tk.END)
        self.entry_hasta.insert(0, hasta)
        
        return desde, hasta
    
    def _actualizar_reporte(self):
        desde, hasta = self._obtener_fechas()
        self._generar_resumen(desde, hasta)
        self._generar_ventas(desde, hasta)
        self._generar_productos(desde, hasta)
        self._generar_clientes(desde, hasta)
    
    def _generar_resumen(self, desde, hasta):
        for w in self.tab_resumen.winfo_children():
            w.destroy()
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            # Total ventas
            cur.execute("SELECT COALESCE(SUM(total), 0), COUNT(*) FROM facturas WHERE fecha BETWEEN ? AND ? AND estado='ACTIVA'", (desde, hasta))
            total_ventas, num_facturas = cur.fetchone()
            
            # Por método de pago
            cur.execute("""
                SELECT metodo_pago, SUM(total) FROM facturas 
                WHERE fecha BETWEEN ? AND ? AND estado='ACTIVA'
                GROUP BY metodo_pago
            """, (desde, hasta))
            por_metodo = cur.fetchall()
            
            # Total gastos
            cur.execute("SELECT COALESCE(SUM(valor), 0) FROM gastos WHERE fecha BETWEEN ? AND ?", (desde, hasta))
            total_gastos = cur.fetchone()[0]
            
            conn.close()
            
            # Mostrar KPIs
            kpi_frame = tk.Frame(self.tab_resumen, bg=COLORES['blanco'])
            kpi_frame.pack(fill=tk.X, padx=30, pady=30)
            
            for titulo, valor, color in [
                ("Total Ventas", format_money(total_ventas), COLORES['exito']),
                ("Facturas", str(num_facturas), COLORES['azul']),
                ("Ticket Promedio", format_money(total_ventas/num_facturas if num_facturas > 0 else 0), COLORES['amarillo']),
                ("Total Gastos", format_money(total_gastos), COLORES['rojo']),
                ("Utilidad Bruta", format_money(total_ventas - total_gastos), COLORES['exito'] if total_ventas > total_gastos else COLORES['rojo'])
            ]:
                card = tk.Frame(kpi_frame, bg=COLORES['blanco'], highlightthickness=1, highlightbackground=COLORES['gris'])
                card.pack(side=tk.LEFT, padx=10, ipadx=20, ipady=15)
                tk.Label(card, text=titulo, font=FUENTES['pequeña'], bg=COLORES['blanco'], fg=COLORES['gris_oscuro']).pack()
                tk.Label(card, text=valor, font=FUENTES['precio'], bg=COLORES['blanco'], fg=color).pack()
            
            # Gráfica
            if MATPLOTLIB_DISPONIBLE and por_metodo:
                fig = Figure(figsize=(10, 4), facecolor=COLORES['blanco'])
                ax = fig.add_subplot(1, 1, 1)
                
                metodos = [m[0] or 'Sin definir' for m in por_metodo]
                valores = [m[1] for m in por_metodo]
                colors = [COLORES['azul'], COLORES['exito'], COLORES['amarillo'], COLORES['rojo'], COLORES['gris_medio']]
                
                ax.pie(valores, labels=metodos, autopct='%1.1f%%', colors=colors[:len(metodos)])
                ax.set_title('Ventas por Método de Pago', fontsize=12, fontweight='bold')
                
                canvas = FigureCanvasTkAgg(fig, master=self.tab_resumen)
                canvas.draw()
                canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        except Exception as e:
            tk.Label(self.tab_resumen, text=f"Error: {e}", bg=COLORES['blanco']).pack(pady=50)
    
    def _generar_ventas(self, desde, hasta):
        for w in self.tab_ventas.winfo_children():
            w.destroy()
        
        cols = ('factura', 'fecha', 'cliente', 'metodo', 'total')
        tree = ttk.Treeview(self.tab_ventas, columns=cols, show='headings', height=15)
        
        for col, w in [('factura', 100), ('fecha', 100), ('cliente', 200), ('metodo', 120), ('total', 120)]:
            tree.heading(col, text=col.upper())
            tree.column(col, width=w, anchor='e' if col == 'total' else 'w')
        
        scroll = ttk.Scrollbar(self.tab_ventas, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=15, pady=15)
        scroll.pack(side=tk.RIGHT, fill=tk.Y, pady=15)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("""
                SELECT f.numero_factura, f.fecha, c.nombre, f.metodo_pago, f.total
                FROM facturas f
                LEFT JOIN clientes c ON f.id_cliente = c.id_cliente
                WHERE f.fecha BETWEEN ? AND ? AND f.estado='ACTIVA'
                ORDER BY f.fecha DESC, f.id_factura DESC
            """, (desde, hasta))
            
            for row in cur.fetchall():
                tree.insert('', 'end', values=(row[0], row[1], row[2] or 'N/A', row[3], format_money(row[4])))
            
            conn.close()
        except:
            pass
    
    def _generar_productos(self, desde, hasta):
        for w in self.tab_productos.winfo_children():
            w.destroy()
        
        cols = ('producto', 'cantidad', 'total')
        tree = ttk.Treeview(self.tab_productos, columns=cols, show='headings', height=15)
        
        for col, w in [('producto', 300), ('cantidad', 100), ('total', 150)]:
            tree.heading(col, text=col.upper())
            tree.column(col, width=w, anchor='e' if col in ['cantidad', 'total'] else 'w')
        
        tree.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("""
                SELECT p.nombre, SUM(d.cantidad), SUM(d.total_linea)
                FROM factura_detalle d
                JOIN productos p ON d.id_producto = p.id_producto
                JOIN facturas f ON d.id_factura = f.id_factura
                WHERE f.fecha BETWEEN ? AND ? AND f.estado='ACTIVA'
                GROUP BY p.id_producto
                ORDER BY SUM(d.cantidad) DESC
            """, (desde, hasta))
            
            for row in cur.fetchall():
                tree.insert('', 'end', values=(row[0], row[1], format_money(row[2])))
            
            conn.close()
        except:
            pass
    
    def _generar_clientes(self, desde, hasta):
        for w in self.tab_clientes.winfo_children():
            w.destroy()
        
        cols = ('cliente', 'compras', 'total')
        tree = ttk.Treeview(self.tab_clientes, columns=cols, show='headings', height=15)
        
        for col, w in [('cliente', 300), ('compras', 100), ('total', 150)]:
            tree.heading(col, text=col.upper())
            tree.column(col, width=w, anchor='e' if col in ['compras', 'total'] else 'w')
        
        tree.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("""
                SELECT c.nombre, COUNT(f.id_factura), SUM(f.total)
                FROM facturas f
                JOIN clientes c ON f.id_cliente = c.id_cliente
                WHERE f.fecha BETWEEN ? AND ? AND f.estado='ACTIVA'
                GROUP BY c.id_cliente
                ORDER BY SUM(f.total) DESC
            """, (desde, hasta))
            
            for row in cur.fetchall():
                tree.insert('', 'end', values=(row[0], row[1], format_money(row[2])))
            
            conn.close()
        except:
            pass
    
    def _exportar(self):
        desde, hasta = self._obtener_fechas()
        
        filepath = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Texto", "*.txt"), ("CSV", "*.csv")],
            initialfilename=f"reporte_{desde}_{hasta}"
        )
        
        if not filepath:
            return
        
        try:
            conn = sqlite3.connect(self.db_path)
            cur = conn.cursor()
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(f"REPORTE RALOZ COL SAS\n")
                f.write(f"Período: {desde} a {hasta}\n")
                f.write(f"Generado: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
                f.write("=" * 50 + "\n\n")
                
                cur.execute("SELECT COALESCE(SUM(total), 0), COUNT(*) FROM facturas WHERE fecha BETWEEN ? AND ? AND estado='ACTIVA'", (desde, hasta))
                total, num = cur.fetchone()
                
                f.write(f"RESUMEN\n")
                f.write(f"Total Ventas: {format_money(total)}\n")
                f.write(f"Número de Facturas: {num}\n")
                f.write(f"Ticket Promedio: {format_money(total/num if num > 0 else 0)}\n\n")
                
                f.write("DETALLE FACTURAS\n")
                f.write("-" * 50 + "\n")
                
                cur.execute("""
                    SELECT f.numero_factura, f.fecha, c.nombre, f.total
                    FROM facturas f LEFT JOIN clientes c ON f.id_cliente = c.id_cliente
                    WHERE f.fecha BETWEEN ? AND ? AND f.estado='ACTIVA'
                    ORDER BY f.fecha
                """, (desde, hasta))
                
                for row in cur.fetchall():
                    f.write(f"{row[0]} | {row[1]} | {row[2] or 'N/A'} | {format_money(row[3])}\n")
            
            conn.close()
            messagebox.showinfo("✅", f"Reporte exportado:\n{filepath}")
        except Exception as e:
            messagebox.showerror("Error", str(e))
